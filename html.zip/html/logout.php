<?php 
// Four steps to closing a session
// (i.e. logging out)

// 1. Find the session
@session_start();
unset($_SESSION['user_id']);  
unset($_SESSION['fullname']); 
unset($_SESSION['usertype']);  
unset($_SESSION['error_message']); // Clear the error message after displaying it 
// 4. Destroy the session
// session_destroy();
header("Location: index.php?logout=1");
?>