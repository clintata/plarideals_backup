<?php
session_start();
include './processes/db.php';
include 'EmailService.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';

    $conn = connect_to_database();

    // Prepare the SQL SELECT statement to check if the email exists in either table
    $stmt = $conn->prepare("
        SELECT 'account' AS source, idNum, fullName FROM account WHERE email = ?
        UNION ALL
        SELECT 'consumer' AS source, consumer_id AS idNum, consumer_name AS fullName FROM consumer WHERE email = ?
    ");

    // Bind the email parameter for both parts of the UNION
    $stmt->bind_param("ss", $email, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email found in either table
        $user = $result->fetch_assoc();
        $name = $user['fullName'];
        $source = $user['source'];

        // Generate reset token and expiration time
        $token = bin2hex(random_bytes(50));
        $expires_at = date("Y-m-d H:i:s", strtotime("+2 minutes")); // Token valid for 2 minutes

        if ($source === 'account') {
            // Update the account table with the reset token
            $stmtUpdate = $conn->prepare("UPDATE account SET reset_token = ?, reset_token_expire = ? WHERE email = ?");
            $stmtUpdate->bind_param("sss", $token, $expires_at, $email);
        } else {
            // Update the consumer table with the reset token
            $stmtUpdate = $conn->prepare("UPDATE consumer SET reset_token = ?, reset_token_expire = ? WHERE email = ?");
            $stmtUpdate->bind_param("sss", $token, $expires_at, $email);
        }

        // Execute the update statement
        if ($stmtUpdate->execute()) {
            // Create the reset link
            $reset_link = "https://plarideals.mooo.com/plarideals/reset_password.php?token=$token";
            $emailService = new EmailService();
            $message = "Click this link to reset your password: $reset_link";
            $resultEmail = $emailService->sendEmail($name, $email, $message);

            if (strpos($resultEmail, 'sent') !== false) {
                $_SESSION['success_message'] = "A password reset link has been sent to your email.";
            } else {
                $_SESSION['error_message'] = "Failed to send the password reset link. Please try again.";
            }
        } else {
            $_SESSION['error_message'] = "Failed to update reset token. Please try again.";
        }

        // Close the update statement
        $stmtUpdate->close();
    } else {
        // Email not found in both tables
        $_SESSION['error_message'] = "Email not found.";
    }

    // Close the database connection and redirect
    $stmt->close();
    $conn->close();
    header("Location: forgot_password.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <?php if (isset($_SESSION['error_message'])): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo $_SESSION['error_message']; ?>',
            });
        </script>
        <?php unset($_SESSION['error_message']); ?>
    <?php elseif (isset($_SESSION['success_message'])): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?php echo $_SESSION['success_message']; ?>',
            });
        </script>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center mb-4">Forgot Password</h2>
                        <form action="forgot_password.php" method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Enter your email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Request Password Reset</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>