<div class="modal fade" id="PaidModals">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Billing Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="PaidForm">
                <div class="modal-body ">
                    <input type="hidden" class="form-control " id="PaididTrackInputs" placeholder="" required>
                    <div class="form-group mb-4">
                        <label for="PaidtitleDisplays" class="form-label fw-bold text-primary">Full Name</label>
                        <h6 id="PaidtitleDisplays" class="border-bottom pb-2 mb-3 text-secondary"></h6>
                    </div>

                    <div class="form-group mb-4">
                        <label for="PaidbalanceInput" class="form-label fw-bold text-primary">Previous Balance</label>
                        <p id="PaidbalanceInput" class="border-bottom pb-2 mb-3 text-secondary"></p>
                    </div>

                    <div class="form-group mb-4">
                        <label for="PaidamountDisplays" class="form-label fw-bold text-primary">Amount</label>
                        <p id="PaidamountDisplays" class="border-bottom pb-2 mb-3 text-secondary"></p>
                    </div>

                    <div class="form-group mb-4">
                        <label for="PaidbilldateDisplays" class="form-label fw-bold text-primary">Bill Date</label>
                        <p id="PaidbilldateDisplays" class="border-bottom pb-2 mb-3 text-secondary"></p>
                    </div>
                    <div class="form-group mb-2">
                        <label for="paidInput">Paid Amount</label>
                        <input type="number" class="form-control" id="paidInput" placeholder="">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../url.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script>
    $(document).ready(function () {
        $('#PaidForm').submit(function (e) {
            e.preventDefault();
            var bNo = $('#PaididTrackInputs').val();
            var paid = $('#paidInput').val();

            $.ajax({
                url: API_URL + '/billingAPI.php/billing',
                method: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({
                    bNo: bNo,
                    paid_amount: paid,
                    action: 'updatepaid'
                }),
                success: function (response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Billing paid successfully',
                    }).then(() => {
                        $('#exampleModalCenters').modal('hide');
                        setTimeout(function () {
                            location.reload();
                        }, 100);
                        generateReport(bNo, paid); // Generate report after success
                    });
                },
                error: function (xhr, status, error) {
                    Swal.fire('Error', 'Error updating consumer', 'error');
                }
            });
        });

        // Function to generate PDF report
        // Ensure you have the custom font in Base64 encoding
        function generateReport(bNo, paidAmount) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Title Header
            doc.setFontSize(20);
            doc.setFont("helvetica", "bold");
            doc.text("PlariDeals Billing", 105, 20, { align: "center" });

            // Subtitle
            doc.setFontSize(16);
            doc.setFont("helvetica", "normal");
            doc.text("Official Billing Report", 105, 30, { align: "center" });

            // Report details with Unicode peso sign
            doc.setFontSize(12);
            doc.text(`Bill No: ${bNo}`, 20, 50);
            doc.text(`Paid Amount: ${paidAmount} PESOS`, 20, 60);  // "PESOS" instead of ₱
            doc.text(`Payment Date: ${new Date().toLocaleDateString()}`, 20, 70);

            // Thank You Message
            doc.setFontSize(12);
            doc.text("Thank you for your payment!", 20, 100);
            doc.text("We appreciate your business.", 20, 110);

            // Footer
            doc.setFontSize(10);
            doc.setTextColor(150);  // Light gray for footer
            doc.text("For any inquiries, please contact support@plarideals.com", 20, 280);

            // Save the PDF
            doc.save(`Billing_Report_${bNo}.pdf`);
        }




    });
</script>