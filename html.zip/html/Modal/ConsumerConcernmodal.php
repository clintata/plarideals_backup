<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Complaint Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="announcementForm">
                <div class="modal-body ">
                    <input type="hidden" class="form-control " id="idTrackInput" placeholder="" required>
                    <div class="form-group mb-2">
                        <label for="MessageInput">Message</label>
                        <input type="text" class="form-control" id="MessageInput" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="noteInput">Note</label>
                        <input type="text" class="form-control" id="noteInput" placeholder="" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../url.js"></script>
<script>
    $(document).ready(function () {
        $('#exampleModalCenter').on('show.bs.modal', function (e) {
            var submitButton = document.getElementById("submitButton");
            var idTrack = $('#idTrackInput').val().trim(); // Fixed the variable name
            if (idTrack === "") {
                submitButton.innerHTML = "Save";
            } else {
                submitButton.innerHTML = "Update";
            }
        });

        $('#announcementForm').submit(function (e) { // Fixed form ID to match the form's ID
            e.preventDefault();
            var user_id = "<?php echo $user_id; ?>";
            var idTrack = $('#idTrackInput').val();
            var note = $('#noteInput').val();
            var message = $('#MessageInput').val();
            if (idTrack === "") {
                $.ajax({
                    url: API_URL + '/ComplaintAPI.php/complaint',
                    method: 'POST',
                    contentType: 'application/json', // Set the content type to JSON
                    data: JSON.stringify({  // Convert data to JSON string
                        cID: user_id,
                        note: note,
                        message: message
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Complaint added successfully',
                        }).then(() => {
                            $('#exampleModalCenter').modal('hide');
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100); // Adjust the delay time as needed
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', xhr.responseText, 'error');
                        setTimeout(function () {
                            location.reload(); // Refresh the page after a short delay
                        }, 100); // Adjust the delay time as needed
                    }
                });
            } else {
                $.ajax({
                    url: API_URL + '/ComplaintAPI.php/complaint',
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        cpID: idTrack,
                        cID: user_id,
                        note: note,
                        message: message,
                       action: 'updatecompalint'
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Complaint updated successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload();
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error updating complaint', 'error');
                    }
                });
            }
        });
    });

</script>