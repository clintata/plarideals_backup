<!-- Modal -->
<div id="userModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">User Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="UsernameForm">
                <div class="modal-body">
                    <input type="hidden" class="form-control" id="UpdateInputs" value="" placeholder="" required>
                    <!-- ID NO  -->
                    <div class="form-group">
                        <label for="userInputs">ID Number</label>
                        <input type="text" class="form-control" id="userInputs" placeholder="" required>
                    </div>
                    <!-- Full Name -->
                    <div class="form-group">
                        <label for="fullNameInput">Full Name</label>
                        <input type="text" class="form-control" id="fullNameInput" placeholder="" required>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label for="emailInput">Email</label>
                        <input type="email" class="form-control" id="emailInput" placeholder="example@gmail.com"
                            required>
                    </div>

                    <!-- Password -->
                    <div class="form-group">
                        <label for="passwordInput">Password</label>
                        <input type="password" class="form-control" id="passwordInput" placeholder="Password" required>
                    </div>

                    <!-- User Role -->
                    <div class="form-group">
                        <label for="usertypeSelect">User Type</label>
                        <select class="form-select" id="usertypeSelect" required>
                            <option value="admin">Admin</option>
                            <option value="biller">Biller</option>
                            <option value="cashier">Cashier</option>
                            <option value="consumer">Consumer</option>
                        </select>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../url.js"></script>
<script>
    $(document).ready(function () {
        // Show modal with the correct button label for Save/Update
        $('#userModal').on('show.bs.modal', function (e) {
            var Update = $('#UpdateInputs').val().trim();
            var submitButton = document.getElementById("submitButton");
            var userInputs = document.getElementById('userInputs');
            if (Update) {
                userInputs.readOnly = true;  // Make ID Number input read-only
            }
            submitButton.innerHTML = (Update === "") ? "Save" : "Update";
        });

        // Form submit handler
        $('#UsernameForm').submit(function (e) {
            e.preventDefault();
            var updatebol = $('#UpdateInputs').val();
            var usercode = $('#userInputs').val();
            var fullName = $('#fullNameInput').val();
            var email = $('#emailInput').val();
            var password = $('#passwordInput').val();
            var usertype = $('#usertypeSelect').val();

            if (updatebol === "") {
                // Create new user (POST)
                $.ajax({
                    url: API_URL + '/userAPI.php/users',
                    method: 'POST',
                    data: {
                        action: 'create',
                        idNum: usercode,
                        fullName: fullName,
                        email: email,
                        password: password,
                        usertype: usertype
                    },
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'User added successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error adding user', 'error');
                    }
                });
            } else {
                // Update existing user (PUT)
                $.ajax({
                    url: API_URL + '/userAPI.php/users',
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        idNum: usercode,
                        fullName: fullName,
                        email: email,
                        password: password,
                        usertype: usertype   
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'User updated successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload();
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error updating user', 'error');
                    }
                });
            }
        });
    });
</script>