<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cubic Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="announcementForm">
                <div class="modal-body ">
                    <input type="hidden" class="form-control " id="idTrackInput" placeholder="" required>
                    <div class="form-group mb-2">
                        <label for="cubicInput">Cubic Defult</label>
                        <input type="number" class="form-control" id="cubicInput" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="defaultInput">Default Amount</label>
                        <input type="number" class="form-control" id="defaultInput" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="firstrate">First Rate</label>
                        <input type="number" class="form-control" id="firstrate" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="secondrate">Second Rate</label>
                        <input type="number" class="form-control" id="secondrate" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="thirdrate">third Rate</label>
                        <input type="number" class="form-control" id="thirdrate" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="firstpenalty">First Penalty</label>
                        <input type="decimal" class="form-control" id="firstpenalty" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="secondpenalty">Second Penalty</label>
                        <input type="number" class="form-control" id="secondpenalty" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="thirdpenalty">Third Penalty</label>
                        <input type="number" class="form-control" id="thirdpenalty" placeholder="" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../url.js"></script>
<script>
    $(document).ready(function () {
        $('#exampleModalCenter').on('show.bs.modal', function (e) {
            var submitButton = document.getElementById("submitButton");
            var idTrack = $('#idTrackInput').val().trim(); // Fixed the variable name
            if (idTrack === "") {
                submitButton.innerHTML = "Save";
            } else {
                submitButton.innerHTML = "Update";
            }
        });

        $('#announcementForm').submit(function (e) { // Fixed form ID to match the form's ID
            e.preventDefault();
            var keyctr = $('#idTrackInput').val();
            var cubic = $('#cubicInput').val();
            var default_amount = $('#defaultInput').val();
            var first_rate = $('#firstrate').val();
            var second_rate = $('#secondrate').val();
            var third_rate = $('#thirdrate').val();
            var first_penalty = $('#firstpenalty').val();
            var second_penalty = $('#secondpenalty').val();
            var third_penalty = $('#thirdpenalty').val();

            $.ajax({
                url: API_URL + '/CubicAPI.php/cubic',
                method: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify({
                    keyctr: keyctr,
                    cubic: cubic,
                    default_amount: default_amount,
                    first_rate: first_rate,
                    second_rate: second_rate,
                    third_rate: third_rate,
                    first_penalty: first_penalty,
                    second_penalty: second_penalty,
                    third_penalty: third_penalty
                }),
                success: function (response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Cubic updated successfully',
                    }).then(() => {
                        $('#userModal').modal('hide');
                        setTimeout(function () {
                            location.reload();
                        }, 100);
                    });
                },
                error: function (xhr, status, error) {
                    Swal.fire('Error', 'Error updating consumer', 'error');
                }
            });

        });
    });

</script>