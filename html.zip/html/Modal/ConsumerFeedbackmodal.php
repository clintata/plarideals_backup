<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">FeedBack Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="announcementForm">
                <div class="modal-body ">
                    <input type="hidden" class="form-control " id="idTrackInput" placeholder="" required>
                    <div class="form-group mb-2">
                        <label for="MessageInput">Message</label>
                        <input type="text" class="form-control" id="MessageInput" placeholder="" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../url.js"></script>
<script>
    $(document).ready(function () {
        $('#announcementForm').submit(function (e) { // Fixed form ID to match the form's ID
            e.preventDefault();
            var message = $('#MessageInput').val();
                $.ajax({
                    url: API_URL + '/ConsumerFeedbackAPI.php/feedback',
                    method: 'POST',
                    contentType: 'application/json', // Set the content type to JSON
                    data: JSON.stringify({  // Convert data to JSON string
                        message: message
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Feedback added successfully',
                        }).then(() => {
                            $('#exampleModalCenter').modal('hide');
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100); // Adjust the delay time as needed
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', xhr.responseText, 'error');
                        setTimeout(function () {
                            location.reload(); // Refresh the page after a short delay
                        }, 100); // Adjust the delay time as needed
                    }
                });
           
        });
    });

</script>