<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Task Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="announcementForm">
                <div class="modal-body ">
                    <input type="hidden" class="form-control " id="idTrackInput" placeholder="" required>
                    <div class="form-group mb-2">
                        <label for="titleInput">Title</label>
                        <input type="text" class="form-control" id="titleInput" placeholder="">
                    </div>
                    <div class="form-group mb-2">
                        <label for="MessageInput">Message</label>
                        <input type="text" class="form-control" id="MessageInput" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="NoteInput">Note</label>
                        <input type="text" class="form-control" id="NoteInput" placeholder="" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="birthDay">Date Start</label>
                        <input type="date" class="form-control" id="birthDay" placeholder="" required>
                    </div>
                    <div class="form-group mb-2 ">
                        <label for="personnelSelect" class="fw-bold">Select Personnel</label>
                        <select class="form-select form-select-md" id="personnelSelect" required>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../url.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        fetchDeveloperLevel();

        function fetchDeveloperLevel() {
            var user_id = "<?php echo $user_id; ?>"; // Get user ID from PHP

            var xhr = new XMLHttpRequest();
            xhr.open('GET', API_URL + '/userAPI.php/users?action=readpersonnel', true);
            xhr.onload = function () {
                if (this.status === 200) {
                    var developerList = JSON.parse(this.responseText);
                    var personnelSelect = document.getElementById('personnelSelect');
                    personnelSelect.innerHTML = ''; // Clear existing options

                    developerList.forEach(function (concernLeve) {
                        var option = document.createElement('option');
                        option.value = concernLeve['idNum'];
                        option.textContent = concernLeve['idNum'] + ' - ' + concernLeve['fullName'];

                        personnelSelect.appendChild(option);
                    });

                    // Add event listener for when the selection changes
                    personnelSelect.addEventListener('change', function () {
                        var selectedOption = personnelSelect.options[personnelSelect.selectedIndex];
                    });
                }
            };
            xhr.send();
        }
    });
    $(document).ready(function () {
        $('#exampleModalCenter').on('show.bs.modal', function (e) {
            var submitButton = document.getElementById("submitButton");
            var idTrack = $('#idTrackInput').val().trim(); // Fixed the variable name
            if (idTrack === "") {
                submitButton.innerHTML = "Save";
            } else {
                submitButton.innerHTML = "Update";
            }
        });

        $('#announcementForm').submit(function (e) { // Fixed form ID to match the form's ID
            e.preventDefault();
            var idTrack = $('#idTrackInput').val();
            var title = $('#titleInput').val();
            var idNum = $('#personnelSelect').val();
            var message = $('#MessageInput').val();
            var birthDay = $('#birthDay').val();
            var type = $('#TypeSelect').val();
            var note = $('#NoteInput').val();
            if (idTrack === "") {
                $.ajax({
                    url: API_URL + '/TasksAPI.php/tasks',
                    method: 'POST',
                    contentType: 'application/json', // Set the content type to JSON
                    data: JSON.stringify({  // Convert data to JSON string
                        idNum: idNum,
                        title: title,
                        message: message,
                        start_date: birthDay,
                        note: note
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Task added successfully',
                        }).then(() => {
                            $('#exampleModalCenter').modal('hide');
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100); // Adjust the delay time as needed
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', xhr.responseText, 'error');
                        setTimeout(function () {
                            location.reload(); // Refresh the page after a short delay
                        }, 100); // Adjust the delay time as needed
                    }
                });
            } else {
                $.ajax({
                    url: API_URL + '/TasksAPI.php/tasks',
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        tID: idTrack,
                        idNum: idNum,
                        title: title,
                        message: message,
                        start_date: birthDay,
                        note: note
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Task updated successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload();
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error updating consumer', 'error');
                    }
                });
            }
        });
    });

</script>