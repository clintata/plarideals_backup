<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">View Complaint</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-3">
                <input type="hidden" id="idTrackInputs">
                <div class="col-md-6">
                    <label class="form-label text-primary">Full Name</label>
                    <h6 id="consumerSelect" class="border-bottom pb-1 text-secondary"></h6>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-primary">Message</label>
                    <p id="MessageInput" class="border-bottom pb-1 text-secondary"></p>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-primary">Note</label>
                    <p id="noteInput" class="border-bottom pb-1 text-secondary"></p>
                </div>
            </div>
        </div>
    </div>
</div>