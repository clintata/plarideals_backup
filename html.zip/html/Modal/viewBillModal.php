<div class="modal fade" id="exampleModalCenters">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">View Bill</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-3">
                <input type="hidden" id="idTrackInputs">

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Full Name</label>
                        <h6 id="titleInput" class="border-bottom pb-1 text-secondary"></h6>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-primary">Amount (₱)</label>
                        <p id="amountinput" class="border-bottom pb-1 text-secondary">₱</p>
                    </div>

                </div>

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Bill Date</label>
                        <p id="billdateinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-primary">Cutting Date</label>
                        <p id="cuttingdateinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Previous Balance (₱)</label>
                        <p id="balanceinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-primary">Previous Meter</label>
                        <p id="previousinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Current Meter</label>
                        <p id="currentinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-primary">Consumption</label>
                        <p id="consumptioninput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Penalty (₱)</label>
                        <p id="penaltyinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-primary">Barangay</label>
                        <p id="barangayinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-primary">Street</label>
                        <p id="streetinput" class="border-bottom pb-1 text-secondary"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>