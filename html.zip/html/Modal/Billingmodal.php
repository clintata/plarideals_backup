<div class="modal fade" id="exampleModalCenter">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Billing Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <form id="announcementForm">
                <div class="modal-body">
                    <input type="hidden" id="idTrackInput">
                    <input type="hidden" id="cubicInput">
                    <input type="hidden" id="defaultamountInput">
                    <input type="hidden" id="firstrateInput">
                    <input type="hidden" id="secondrateInput">
                    <input type="hidden" id="thirdrateInput">
                    <input type="hidden" id="firstpenaltyInput">
                    <input type="hidden" id="secondpenaltyInput">
                    <input type="hidden" id="thirdpenaltyInput">
                    <div class="form-group mb-2">
                        <label for="consumerSelect" class="fw-bold">Select Consumer</label>
                        <select class="form-select form-select-sm" id="consumerSelect" required></select>
                    </div>

                    <!-- Smaller input fields with form-control-sm -->
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="previousInput">Previous Meter</label>
                            <input type="number" class="form-control form-control-sm" id="previousInput" readonly>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label for="currentInput">Current Meter</label>
                            <input type="number" class="form-control form-control-sm" id="currentInput">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="consumptionInput">Consumption</label>
                            <input type="number" class="form-control form-control-sm" id="consumptionInput" readonly>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label for="penaltyInput">Penalty</label>
                            <input type="number" class="form-control form-control-sm" id="penaltyInput" readonly>
                        </div>
                    </div>

                    <div class="row">
    <div class="col-md-6 mb-2">
        <label for="AmountInput">Amount</label>
        <div class="input-group input-group-sm">
            <span class="input-group-text" style="background-color: transparent; box-shadow: none;">₱</span>
            <input type="number" class="form-control form-control-sm" id="AmountInput" readonly>
        </div>
    </div>
    <div class="col-md-6 mb-2">
        <label for="balanceInput">Previous Balance</label>
        <div class="input-group input-group-sm">
            <span class="input-group-text" style="background-color: transparent; box-shadow: none;">₱</span>
            <input type="number" class="form-control form-control-sm" id="balanceInput" readonly>
        </div>
    </div>
</div>
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="billdate">Due Date</label>
                            <input type="date" class="form-control form-control-sm" id="billdate" readonly>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label for="cuttingdate">Cutting Date</label>
                            <input type="date" class="form-control form-control-sm" id="cuttingdate" readonly>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="barangayInput">Barangay</label>
                            <input type="text" class="form-control form-control-sm" id="barangayInput" readonly>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label for="streetInput">Street</label>
                            <input type="text" class="form-control form-control-sm" id="streetInput" readonly>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" id="submitButton">Save</button>
                    <button type="button" class="btn btn-light-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                </div>
            </form>

        </div>
    </div>
</div>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script src="../url.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        fetchDeveloperLevel();

        $('#exampleModalCenter').on('show.bs.modal', function () {
            var submitButton = document.getElementById("submitButton");
            var idTrack = $('#idTrackInput').val().trim();
            if (idTrack === "") {
                submitButton.innerHTML = "Save";
                fetCutOffLevel();
                fetCubicLevel();
            } else {
                submitButton.innerHTML = "Update";
            }

            // Initialize Select2 on consumerSelect
            $('#consumerSelect').select2({
                dropdownParent: $('#exampleModalCenter'),
                width: '100%',
                placeholder: "Select a consumer",
                allowClear: true
            });
        });

        function fetchDeveloperLevel() {
            var user_id = "<?php echo $user_id; ?>"; // Get user ID from PHP

            var xhr = new XMLHttpRequest();
            xhr.open('GET', API_URL + '/consumerAPI.php/consumer?action=consumerbill', true);
            xhr.onload = function () {
                if (this.status === 200) {
                    var consumerList = JSON.parse(this.responseText);
                    var consumerSelect = document.getElementById('consumerSelect');
                    consumerSelect.innerHTML = ''; // Clear existing options

                    consumerList.forEach(function (consumer) {
                        var option = document.createElement('option');
                        option.value = consumer['consumer_id'];
                        option.textContent = consumer['consumer_id'] + ' - ' + consumer['consumer_name'];
                        option.setAttribute('data-previous-meter', consumer['current_meter'] != null ? consumer['current_meter'] : 0);
                        option.setAttribute('data-previous-balance', consumer['previous_balance'] != null ? consumer['previous_balance'] : 0);
                        option.setAttribute('data-barangay', consumer['barangay'] != null ? consumer['barangay'] : '');
                        option.setAttribute('data-street', consumer['street'] != null ? consumer['street'] : '');
                        consumerSelect.appendChild(option);
                    });

                    // Function to clear and set input fields based on the selected option
                    function updateInputFields(selectedOption) {
                        // Clear all input fields first
                        document.getElementById('previousInput').value = '';
                        document.getElementById('currentInput').value = '';
                        document.getElementById('balanceInput').value = '';
                        document.getElementById('barangayInput').value = '';
                        document.getElementById('streetInput').value = '';

                        // Set new values or default to 0 or empty if null
                        document.getElementById('previousInput').value = selectedOption.getAttribute('data-previous-meter') || 0;
                        document.getElementById('currentInput').value = 0; // Default to 0 for current meter
                        document.getElementById('balanceInput').value = selectedOption.getAttribute('data-previous-balance') || 0;
                        document.getElementById('barangayInput').value = selectedOption.getAttribute('data-barangay') || '';
                        document.getElementById('streetInput').value = selectedOption.getAttribute('data-street') || '';
                    }

                    // Auto-populate with the first option's data if available
                    if (consumerSelect.options.length > 0) {
                        updateInputFields(consumerSelect.options[0]);
                    }

                    // Event listener to clear and update fields on selection change
                    $('#consumerSelect').on('change', function () {
                        var selectedOption = this.options[this.selectedIndex];
                        updateInputFields(selectedOption);
                    });
                }
            };
            xhr.send();
        }

        function fetCutOffLevel() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', API_URL + '/ScheduleAPI.php/schedule', true);
            xhr.onload = function () {
                if (this.status === 200) {
                    try {
                        var concernLevelList = JSON.parse(this.responseText);
                        console.log(concernLevelList); // Debug output

                        if (concernLevelList.length > 0) {
                            // Set values from the first entry only
                            var firstConcern = concernLevelList[0];
                            document.getElementById('billdate').value = firstConcern.due_date;
                            document.getElementById('cuttingdate').value = firstConcern.cutting_date;
                        }
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                    }
                } else {
                    console.error('Failed to fetch data. Status:', this.status);
                }
            };
            xhr.send();
        }

        function fetCubicLevel() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', API_URL + '/CubicAPI.php/cubic', true);
            xhr.onload = function () {
                if (this.status === 200) {
                    try {
                        var concernLevelList = JSON.parse(this.responseText);
                        console.log(concernLevelList); // Debug output

                        if (concernLevelList.length > 0) {
                            // Set values from the first entry only
                            var firstConcern = concernLevelList[0];

                            // Set hidden input fields with data from firstConcern
                            document.getElementById('cubicInput').value = firstConcern.cubic;
                            document.getElementById('defaultamountInput').value = firstConcern.default_amount;
                            document.getElementById('firstrateInput').value = firstConcern.first_rate;
                            document.getElementById('secondrateInput').value = firstConcern.second_rate;
                            document.getElementById('thirdrateInput').value = firstConcern.third_rate;
                            document.getElementById('firstpenaltyInput').value = firstConcern.first_penalty;
                            document.getElementById('secondpenaltyInput').value = firstConcern.second_penalty;
                            document.getElementById('thirdpenaltyInput').value = firstConcern.third_penalty;
                        }
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                    }
                } else {
                    console.error('Failed to fetch data. Status:', this.status);
                }
            };
            xhr.send();
        }

        document.getElementById('currentInput').addEventListener('input', function () {
            // Get required values
            const previousMeter = parseFloat(document.getElementById('previousInput').value) || 0;
            const currentMeter = parseFloat(this.value) || 0;
            const firstRate = parseFloat(document.getElementById('firstrateInput').value) || 0;
            const secondRate = parseFloat(document.getElementById('secondrateInput').value) || 0;
            const thirdRate = parseFloat(document.getElementById('thirdrateInput').value) || 0;
            const defaultAmount = parseFloat(document.getElementById('defaultamountInput').value) || 0;
            const firstPenalty = parseFloat(document.getElementById('firstpenaltyInput').value) || 0;
            const secondPenalty = parseFloat(document.getElementById('secondpenaltyInput').value) || 0;
            const thirdPenalty = parseFloat(document.getElementById('thirdpenaltyInput').value) || 0;

            const consumption = Math.max(0, currentMeter - previousMeter);
            document.getElementById('consumptionInput').value = consumption;

            let amount = 0;
            if (consumption <= 8) {
                amount = defaultAmount;
            } else if (consumption > 8 && consumption <= 18) {
                amount = defaultAmount + ((consumption - 8) * firstRate);
            } else {
                amount = defaultAmount + (10 * firstRate) + ((consumption - 18) * secondRate);
            }

            let penalty = 0;
            if (consumption <= 8) {
                penalty = 5.00; // Base penalty
            } else if (consumption > 8 && consumption <= 18) {
                penalty = (firstPenalty * (consumption - 8) + 5).toFixed(2);
            } else if (consumption > 18 && consumption <= 30) {
                penalty = (firstPenalty * 10 + secondPenalty * (consumption - 18) + 5).toFixed(2);
            } else if (consumption > 30) {
                penalty = (firstPenalty * 10 + secondPenalty * 12 + thirdPenalty * (consumption - 30) + 5).toFixed(2);
            }

            penalty = parseFloat(penalty);

            document.getElementById('AmountInput').value = amount.toFixed(2);
            document.getElementById('penaltyInput').value = penalty.toFixed(2);
        });

    });

    $(document).ready(function () {
        $('#exampleModalCenter').on('show.bs.modal', function (e) {
            var submitButton = document.getElementById("submitButton");
            var idTrack = $('#idTrackInput').val().trim(); // Fixed the variable name
            if (idTrack === "") {
                submitButton.innerHTML = "Save";
            } else {
                submitButton.innerHTML = "Update";
            }
        });

        $('#announcementForm').submit(function (e) {
            e.preventDefault();
            var bNo = $('#idTrackInput').val();
            var cID = $('#consumerSelect').val();
            var amount = $('#AmountInput').val();
            var bill_date = $('#billdate').val();
            var cutting_date = $('#cuttingdate').val();
            var barangay = $('#barangayInput').val();
            var street = $('#streetInput').val();
            var previous_balance = $('#balanceInput').val();
            var previous_meter = $('#previousInput').val();
            var current_meter = $('#currentInput').val();
            var consumption = $('#consumptionInput').val();
            var penalty = $('#penaltyInput').val();

            if (bNo === "") {
                $.ajax({
                    url: API_URL + '/billingAPI.php/billing',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({  
                        cID: cID,
                        amount: amount,
                        bill_date: bill_date,
                        cutting_date: cutting_date,
                        barangay: barangay,
                        street: street,
                        previous_balance: previous_balance,
                        previous_meter: previous_meter,
                        current_meter: current_meter,
                        consumption: consumption,
                        penalty: penalty
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Billing added successfully',
                        }).then(() => {
                            $('#exampleModalCenter').modal('hide');
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100); // Adjust the delay time as needed
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', xhr.responseText, 'error');
                        setTimeout(function () {
                            location.reload(); // Refresh the page after a short delay
                        }, 100); // Adjust the delay time as needed
                    }
                });
            } else {
                $.ajax({
                    url: API_URL + '/billingAPI.php/billing',
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        bNo: bNo,
                        cID: cID,
                        amount: amount,
                        bill_date: bill_date,
                        cutting_date: cutting_date,
                        barangay: barangay,
                        street: street
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Billing updated successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload();
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error updating consumer', 'error');
                    }
                });
            }
        });
    });

</script>