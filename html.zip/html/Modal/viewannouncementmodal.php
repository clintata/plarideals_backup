<div class="modal fade" id="announceModalCenters">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">View Announcement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="idTrackInputs" placeholder="">

                <div class="form-group mb-3">
                    <label for="titleInput">Title</label>
                    <h6 id="titleDisplays"></h6> <!-- Replaced input with h6 for title -->
                </div>

                <div class="form-group mb-3">
                    <label for="MessageInput">Message</label>
                    <p id="messageDisplays"></p> <!-- Replaced input with p for message -->
                </div>

                <div class="form-group mb-3">
                    <label for="birthDay">Date</label>
                    <p id="dateDisplays"></p> <!-- Replaced input with p for date -->
                </div>
            </div>
        </div>
    </div>
</div>
