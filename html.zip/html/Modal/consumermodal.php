<div id="userModal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">User Maintenance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="UsernameForm">
                <div class="modal-body">
                    <input type="hidden" class="form-control form-control-sm" id="UpdateInputs" value="" required>

                    <!-- Full Name -->
                    <div class="form-group row mb-2">
                        <label for="fullNameInput" class="col-sm-2 col-form-label">Full Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control form-control-sm" id="fullNameInput" required>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="form-group row mb-2">
                        <label for="emailInput" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-8">
                            <input type="email" class="form-control form-control-sm" id="emailInput"
                                placeholder="example@gmail.com" required>
                        </div>
                    </div>

                    <!-- Phone Number -->
                    <div class="form-group row mb-2">
                        <label for="phoneInput" class="col-sm-2 col-form-label">Phone</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control form-control-sm" id="phoneInput" required>
                        </div>
                    </div>

                    <!-- Municipality, Barangay, and purok side by side -->
                    <div class="form-group row mb-2">
                        <label for="addressInput" class="col-sm-2 col-form-label">Address</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control form-control-sm" id="addressInput" required>
                        </div>
                    </div>
                    <div class="form-group row mb-2">
                        <label for="barangayInput" class="col-sm-2 col-form-label">Barangay</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control form-control-sm" id="barangayInput" required>
                        </div>
                    </div>
                    <div class="form-group row mb-2">
                        <label for="purokInput" class="col-sm-2 col-form-label">Purok</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control form-control-sm" id="streetInput" required>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="form-group row mb-2">
                        <label for="passwordInput" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control form-control-sm" id="passwordInput"
                                placeholder="Password" required>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" id="submitButton">Saved</button>
                    <button type="button" class="btn btn-light-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                </div>
            </form>

        </div>
    </div>
</div>

<script src="../url.js"></script>
<script>
    $(document).ready(function () {
        // Show modal with the correct button label for Save/Update
        $('#userModal').on('show.bs.modal', function (e) {
            var Update = $('#UpdateInputs').val().trim();
            var submitButton = document.getElementById("submitButton");
            submitButton.innerHTML = (Update === "") ? "Save" : "Update";
        });

        // Form submit handler
        $('#UsernameForm').submit(function (e) {
            e.preventDefault();

            var updatebol = $('#UpdateInputs').val();
            var fullName = $('#fullNameInput').val();
            var email = $('#emailInput').val();
            var password = $('#passwordInput').val();
            var address = $('#addressInput').val();
            var phone = $('#phoneInput').val();
            var barangay = $('#barangayInput').val();
            var street = $('#streetInput').val();

            if (updatebol === "") {
                // Create new user (POST)

                $.ajax({
                    url: API_URL + '/consumerAPI.php/consumer',
                    method: 'POST',
                    data: {
                        action: 'create',
                        consumer_name: fullName,
                        email: email,
                        password: password,
                        address: address,
                        phone: phone,
                        barangay: barangay,
                        street: street
                    },
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Consumer added successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            // alert(API_URL +'/consumerAPI.php/consumer' )
                            setTimeout(function () {
                                location.reload(); // Refresh the page after a short delay
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error adding user', 'error');
                    }
                });
            } else {
                // Update existing user (PUT)
                $.ajax({
                    url: API_URL + '/consumerAPI.php/consumer',
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        consumer_id: updatebol,
                        consumer_name: fullName,
                        email: email,
                        password: password,
                        address: address,
                        phone: phone,
                        barangay: barangay,
                        street: street
                    }),
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Consumer updated successfully',
                        }).then(() => {
                            $('#userModal').modal('hide');
                            setTimeout(function () {
                                location.reload();
                            }, 100);
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'Error updating consumer', 'error');
                    }
                });
            }
        });
    });
</script>