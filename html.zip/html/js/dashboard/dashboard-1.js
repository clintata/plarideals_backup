(function($) {
    /* "use strict" */
    var dlabChartlist = function(){
        
        var chartBar = function(data){
            // Parse the API data to get month names, total_paid, and total_unpaid
            const months = data.map(item => item.month_name);
            const income = data.map(item => item.total_paid);
            const outcome = data.map(item => item.total_unpaid);
            
            var options = {
                series: [
                    { name: 'Income', data: income },
                    { name: 'Outcome', data: outcome }
                ],
                chart: {
                    type: 'bar',
                    height: 200,
                    toolbar: { show: false }
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '57%',
                        borderRadius: 12
                    }
                },
                colors: ['#80ec67', '#fe7d65'],
                dataLabels: { enabled: false },
                xaxis: {
                    categories: months,
                    labels: {
                        style: {
                            colors: '#3e4954',
                            fontSize: '13px',
                            fontFamily: 'poppins',
                            fontWeight: 400
                        }
                    }
                },
                yaxis: {
                    labels: {
                        offsetX: -16,
                        style: {
                            colors: '#3e4954',
                            fontSize: '13px',
                            fontFamily: 'poppins',
                            fontWeight: 400
                        }
                    }
                },
                fill: {
                    opacity: 1,
                    colors: ['#80ec67', '#fe7d65']
                },
                tooltip: {
                    y: {
                        formatter: function(val) {
                            return "₱" + val + "";
                        }
                    }
                },
                responsive: [
                    {
                        breakpoint: 1600,
                        options: {
                            chart: { height: 400 }
                        }
                    },
                    {
                        breakpoint: 575,
                        options: {
                            chart: { height: 250 }
                        }
                    }
                ]
            };

            var chart = new ApexCharts(document.querySelector("#chartBar"), options);
            chart.render();
        };

        var fetchDataAndRenderChart = function(){
            fetch("https://plarideals.mooo.com/app/view/dashboardAPI.php/dashboard?action=readAdminDash")
                .then(response => response.json())
                .then(data => {
                    chartBar(data);
                })
                .catch(error => console.error('Error fetching data:', error));
        };
        
        return {
            load: function() {
                fetchDataAndRenderChart();
            }
        };
    }();

    jQuery(window).on('load', function(){
        setTimeout(function(){
            dlabChartlist.load();
        }, 1000); 
    });
})(jQuery);
