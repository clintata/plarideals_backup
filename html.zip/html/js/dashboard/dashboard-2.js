(function($) {
    /* "use strict" */
    var dlabChartlist = function() {
        
        var chartBar = function(data) {
            // Parse the API data to get month names and total_paid (for Income only)
            const months = data.map(item => item.month_name);
            const income = data.map(item => item.consumption);
            
            var options = {
                series: [
                    { name: 'Income', data: income }
                ],
                chart: {
                    type: 'bar',
                    height: 200,
                    toolbar: { show: false },
                    animations: { // Smooth loading animation
                        enabled: true,
                        easing: 'easeinout',
                        speed: 800
                    }
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '50%', // Slightly slimmer bars
                        borderRadius: 10, // Rounded bar corners
                    }
                },
                colors: ['#3B82F6'], // New blue color for a fresh look
                dataLabels: {
                    enabled: true,
                    style: {
                        colors: ['#ffffff'],
                        fontSize: '12px',
                        fontWeight: 'bold',
                    },
                    offsetY: -10, // Position labels slightly above bars
                },
                xaxis: {
                    categories: months,
                    labels: {
                        style: {
                            colors: '#64748B', // Light gray for readability
                            fontSize: '13px',
                            fontFamily: 'poppins',
                            fontWeight: 500
                        }
                    },
                    axisBorder: {
                        show: true,
                        color: '#E5E7EB'
                    }
                },
                yaxis: {
                    labels: {
                        offsetX: -10,
                        style: {
                            colors: '#64748B',
                            fontSize: '13px',
                            fontFamily: 'poppins',
                            fontWeight: 500
                        }
                    }
                },
                fill: {
                    opacity: 0.9, // Slightly transparent for a modern look
                    colors: ['#3B82F6']
                },
                tooltip: {
                    theme: 'dark', // Dark theme for contrast
                    y: {
                        formatter: function(val) {
                            return "Consumtion " + val.toLocaleString(); // Add comma separator
                        }
                    }
                },
                grid: {
                    borderColor: '#E5E7EB',
                    strokeDashArray: 5, // Dashed grid lines
                },
                responsive: [
                    {
                        breakpoint: 1600,
                        options: {
                            chart: { height: 400 }
                        }
                    },
                    {
                        breakpoint: 575,
                        options: {
                            chart: { height: 250 }
                        }
                    }
                ]
            };

            var chart = new ApexCharts(document.querySelector("#chartBar"), options);
            chart.render();
        };

        var fetchDataAndRenderChart = function() {
            fetch("https://plarideals.mooo.com/app/view/dashboardAPI.php/dashboard?action=readConsumerDash")
                .then(response => response.json())
                .then(data => {
                    chartBar(data);
                })
                .catch(error => console.error('Error fetching data:', error));
        };
        
        return {
            load: function() {
                fetchDataAndRenderChart();
            }
        };
    }();

    jQuery(window).on('load', function() {
        setTimeout(function() {
            dlabChartlist.load();
        }, 1000); 
    });
})(jQuery);
