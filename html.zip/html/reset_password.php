<?php
session_start();
include './processes/db.php';


date_default_timezone_set('UTC');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $_SESSION['error_message'] = "Passwords do not match.";
        header("Location: reset_password.php?token=" . $token);
        exit();
    }

    $conn = connect_to_database();
    $conn->query("SET time_zone = '+00:00';");

    $stmt = $conn->prepare("
        SELECT 'account' AS source, idNum FROM account WHERE reset_token = ? AND reset_token_expire > NOW()
        UNION ALL
        SELECT 'consumer' AS source, consumer_id AS idNum FROM consumer WHERE reset_token = ? AND reset_token_expire > NOW()
    ");

    // Bind the token parameter for both parts of the UNION
    $stmt->bind_param("ss", $token, $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Token found in either table
        $user = $result->fetch_assoc();
        $source = $user['source'];

        // Prepare the appropriate update statement based on the source table
        if ($source === 'account') {
            $stmtUpdate = $conn->prepare("UPDATE account SET password = ?, reset_token = NULL, reset_token_expire = NULL WHERE reset_token = ?");
        } else {
            $stmtUpdate = $conn->prepare("UPDATE consumer SET password = ?, reset_token = NULL, reset_token_expire = NULL WHERE reset_token = ?");
        }

        // Bind the parameters for the update statement
        $stmtUpdate->bind_param("ss", $new_password, $token);

        if ($stmtUpdate->execute()) {
            $_SESSION['success_message'] = "Password has been reset successfully.";
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Failed to reset password. Please try again.";
        }

        // Close the update statement
        $stmtUpdate->close();
    } else {
        // Token not found or expired
        $_SESSION['error_message'] = "Invalid or expired token. Current time: " . date("Y-m-d H:i:s");
    }
    // Close the database connection and redirect
    $stmt->close();
    $conn->close();
    header("Location: forgot_password.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <?php if (isset($_SESSION['error_message'])): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo $_SESSION['error_message']; ?>',
            });
        </script>
        <?php unset($_SESSION['error_message']); ?>
    <?php elseif (isset($_SESSION['success_message'])): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?php echo $_SESSION['success_message']; ?>',
            });
        </script>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center mb-4">Reset Password</h2>
                        <form action="reset_password.php" method="POST">
                            <input type="hidden" name="token"
                                value="<?php echo htmlspecialchars($_GET['token'] ?? ''); ?>">
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" name="new_password" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Reset Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>