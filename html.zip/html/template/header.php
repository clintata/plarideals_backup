<link rel="shortcut icon" type="image/png" href="images/favicon.png" />
  <link href="./vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="./vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet" />
  <link href="./vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="./vendor/nouislider/nouislider.min.css" />
  <!-- Style css -->
  <link href="./css/style.css" rel="stylesheet" />

  <script src="./vendor/global/global.min.js"></script>
    <script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
    <script src="./vendor/sweetalert2/dist/sweetalert2.min.js"></script>
    <script src="./js/plugins-init/sweetalert.init.js"></script>
    <!-- Apex Chart -->
    <script src="./vendor/apexchart/apexchart.js"></script>
    <script src="./vendor/nouislider/nouislider.min.js"></script>
    <script src="./vendor/wnumb/wNumb.js"></script>

    <!-- Dashboard 1 -->
    <script src="./js/dashboard/dashboard-1.js"></script>

    <script src="./js/custom.min.js"></script>
    <script src="./js/dlabnav-init.js"></script>
    <script src="./js/demo.js"></script>
    <script src="./js/styleSwitcher.js"></script>