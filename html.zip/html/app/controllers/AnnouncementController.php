<?php
session_start();
require_once __DIR__ . '/../models/Announcement.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class AnnouncementController
{
    private $db;
    private $announcementbase;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->announcementbase = new AnnouncementBase($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->announcementbase->read();
        $announcementbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($announcementbases)) {
            echo json_encode($announcementbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->announcementbase->title = $data['title'] ?? '';
        $this->announcementbase->message = $data['message'] ?? '';
        $this->announcementbase->date = $data['date'] ?? '';
        $this->announcementbase->posted_by =   $_SESSION['fullname'] ?? '';
        $this->announcementbase->atype = $data['atype'] ?? '';
        if ($this->announcementbase->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Announcement created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Announcement not created successfully.'));
            exit;
        }
    }

    public function addnoti($aID,$announcement_id)
    {
        $data = json_decode(file_get_contents('php://input'), true);
        if ($this->announcementbase->createNoti($aID,$announcement_id)) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Announcement created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Announcement not created successfully.'));
            exit;
        }
    }

    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->announcementbase->aID = $data['id'] ?? '';

        if ($this->announcementbase->delete()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Announcement deleted successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Announcement not deleted successfully.']);
            exit;
        }
    }
}
?>
