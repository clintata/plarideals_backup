<?php
session_start();
require_once __DIR__ . '/../models/Billing.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function
require_once __DIR__ . '/../../processes/sender.php'; // Include your connection function

class BillingController
{
    private $db;
    private $billing;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->billing = new Billing($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->billing->read();
        $billingbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];

        if (!empty($billingbases)) {
            echo json_encode($billingbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readConsumer()
    {
        $this->billing->cID = $_SESSION['user_id'] ?? '';
        $stmt = $this->billing->readConsumer($this->billing->cID);
        $billingbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];

        if (!empty($billingbases)) {
            echo json_encode($billingbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->billing->cID = $data['cID'] ?? '';
        $this->billing->amount = $data['amount'] ?? '';
        $this->billing->bill_date = $data['bill_date'] ?? '';
        $this->billing->cutting_date = $data['cutting_date'] ?? '';
        $this->billing->barangay = $data['barangay'] ?? '';
        $this->billing->street = $data['street'] ?? '';
        $this->billing->previous_balance = $data['previous_balance'] ?? '';
        $this->billing->previous_meter = $data['previous_meter'] ?? '';
        $this->billing->current_meter = $data['current_meter'] ?? '';
        $this->billing->consumption = $data['consumption'] ?? '';
        $this->billing->penalty = $data['penalty'] ?? '';

        if ($this->billing->create()) {
            ob_clean();
            // SendMessage(
            //     $this->billing->cID,
            //     'Your water bill for ' . date('F') . ' is ' . $this->billing->amount . ', due by ' . $this->billing->bill_date . ". Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS"
            // );    
            $this->createNoti(
                $this->billing->cID,
                'Your water bill for ' . date('F') . ' is ' . $this->billing->amount . ', due by ' . $this->billing->bill_date . ". Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS"
            );   
            echo json_encode(array('success' => true, 'message' => 'Billing created successfully.'));   
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Billing not created successfully.'));
            exit;
        }
    }

    public function createNoti($id,$Message)
    {

        if ($this->billing->createNoti($id,$Message)) {

        } else {

        }
    }

    public function update()
    {
        // Parse the PUT data
        $data = json_decode(file_get_contents('php://input'), true);

        // Set user properties using parsed data
        $this->billing->bNo = $data['bNo'] ?? '';
        $this->billing->cID = $data['cID'] ?? '';
        $this->billing->amount = $data['amount'] ?? '';
        $this->billing->bill_date = $data['bill_date'] ?? '';
        $this->billing->cutting_date = $data['cutting_date'] ?? '';
        $this->billing->barangay = $data['barangay'] ?? '';
        $this->billing->previous_balance = $data['previous_balance'] ?? '';
        $this->billing->previous_meter = $data['previous_meter'] ?? '';
        $this->billing->current_meter = $data['current_meter'] ?? '';
        $this->billing->consumption = $data['consumption'] ?? '';
        $this->billing->penalty = $data['penalty'] ?? '';

        if ($this->billing->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' => $this->billing]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->billing]);
            exit;
        }
    }

    public function updatePaid()
    {
        // Parse the PUT data
        $data = json_decode(file_get_contents('php://input'), true);

        // Set user properties using parsed data
        $this->billing->bNo = $data['bNo'] ?? '';
        $this->billing->paid_amount = $data['paid_amount'] ?? '';
        if ($this->billing->updatePaid()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' => $this->billing]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->billing]);
            exit;
        }
    }

    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->billing->bNo = $data['id'] ?? '';

        if ($this->billing->delete()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Billing deleted successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Billing not deleted successfully.']);
            exit;
        }
    }
}
?>