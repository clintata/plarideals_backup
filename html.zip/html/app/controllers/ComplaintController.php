<?php
session_start();
require_once __DIR__ . '/../models/Complaint.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class ComplaintController
{
    private $db;
    private $complaint;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->complaint = new Complaint($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->complaint->read();
        $complaintbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($complaintbases)) {
            echo json_encode($complaintbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readConsumer($id)
    {
        $stmt = $this->complaint->readConsumer($id);
        $complaintbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($complaintbases)) {
            echo json_encode($complaintbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    
    
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->complaint->cID = $data['cID'] ?? '';
        $this->complaint->message = $data['message'] ?? '';
        $this->complaint->note = $data['note'] ?? '';
        $this->complaint->assigned_to = $data['assigned_to'] ?? '';
        $this->complaint->role =   $data['role'] ?? '';
        if ($this->complaint->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Complaint created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Complaint not created successfully.'));
            exit;
        }
    }


    public function update()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->complaint->cID = $data['cID'] ?? '';
        $this->complaint->message = $data['message'] ?? '';
        $this->complaint->note = $data['note'] ?? '';
        $this->complaint->assigned_to = $data['assigned_to'] ?? '';
        $this->complaint->role =   $data['role'] ?? '';
        $this->complaint->cpID = $data['cpID'] ?? '';

        if ($this->complaint->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->complaint]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->complaint]);
            exit;
        }
    }

    public function updateComplaint()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->complaint->cID = $data['cID'] ?? '';
        $this->complaint->message = $data['message'] ?? '';
        $this->complaint->note = $data['note'] ?? '';
        $this->complaint->cpID = $data['cpID'] ?? '';

        if ($this->complaint->updateComplaint()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->complaint]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->complaint]);
            exit;
        }
    }

    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->complaint->cpID = $data['id'] ?? '';

        if ($this->complaint->delete()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Task deleted successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Task not deleted successfully.']);
            exit;
        }
    }
}
?>
