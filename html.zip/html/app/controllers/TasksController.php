<?php
session_start();
require_once __DIR__ . '/../models/Tasks.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class TasksController
{
    private $db;
    private $feedback;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->feedback = new Tasks($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->feedback->read();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->feedback->idNum = $data['idNum'] ?? '';
        $this->feedback->title = $data['title'] ?? '';
        $this->feedback->message = $data['message'] ?? '';
        $this->feedback->note =   $data['note'] ?? '';
        $this->feedback->start_date = $data['start_date'] ?? '';
        if ($this->feedback->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Task created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Task not created successfully.'));
            exit;
        }
    }


    public function update()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->feedback->idNum = $data['idNum'] ?? '';
        $this->feedback->tID = $data['tID'] ?? '';
        $this->feedback->title = $data['title'] ?? '';
        $this->feedback->message = $data['message'] ?? '';
        $this->feedback->note =   $data['note'] ?? '';
        $this->feedback->start_date = $data['start_date'] ?? '';

        if ($this->feedback->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->feedback]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->feedback]);
            exit;
        }
    }

    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->feedback->tID = $data['id'] ?? '';

        if ($this->feedback->delete()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Task deleted successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Task not deleted successfully.']);
            exit;
        }
    }
}
?>
