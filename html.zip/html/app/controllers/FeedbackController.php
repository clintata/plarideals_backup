<?php
session_start();
require_once __DIR__ . '/../models/Feedback.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class FeedbackController
{
    private $db;
    private $feedback;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->feedback = new Feedback($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->feedback->read();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readConsumer()
    {
        $this->feedback->idNum = $_SESSION['user_id']?? '';
        $stmt = $this->feedback->readConsumer($this->feedback->idNum);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->feedback->message = $data['message'] ?? '';
        $this->feedback->fID = $_SESSION['user_id']?? '';
        if ($this->feedback->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Feedback successfully passed.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'Feedback not passed.'));
            exit;
        }
    }

    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->feedback->fID = $data['id'] ?? '';

        if ($this->feedback->delete()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Feedback deleted successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Feedback not deleted successfully.']);
            exit;
        }
    }
}
?>
