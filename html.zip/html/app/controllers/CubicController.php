<?php
session_start();
require_once __DIR__ . '/../models/Cubic.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class CubicController
{
    private $db;
    private $cubic;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->cubic = new Cubic($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->cubic->read();
        $cubicbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($cubicbases)) {
            echo json_encode($cubicbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function update()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->cubic->cubic = $data['cubic'] ?? '';
        $this->cubic->default_amount = $data['default_amount'] ?? '';
        $this->cubic->first_rate = $data['first_rate'] ?? '';
        $this->cubic->second_rate = $data['second_rate'] ?? '';
        $this->cubic->third_rate =   $data['third_rate'] ?? '';
        $this->cubic->first_penalty = $data['first_penalty'] ?? '';
        $this->cubic->second_penalty = $data['second_penalty'] ?? '';
        $this->cubic->third_penalty =   $data['third_penalty'] ?? '';
        $this->cubic->keyctr = $data['keyctr'] ?? '';
        if ($this->cubic->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->cubic]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->cubic]);
            exit;
        }
    }
}
?>
