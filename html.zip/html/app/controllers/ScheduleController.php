<?php
session_start();
require_once __DIR__ . '/../models/Schedule.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class ScheduleController
{
    private $db;
    private $schedule;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->schedule = new Schedule($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function read()
    {
        $stmt = $this->schedule->read();
        $schedulebases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($schedulebases)) {
            echo json_encode($schedulebases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }



    public function update()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->schedule->reading_date = $data['reading_date'] ?? '';
        $this->schedule->due_date = $data['due_date'] ?? '';
        $this->schedule->cutting_date = $data['cutting_date'] ?? '';
        $this->schedule->keyctr = $data['keyctr'] ?? '';
        if ($this->schedule->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->schedule]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->schedule]);
            exit;
        }
    }
}
?>
