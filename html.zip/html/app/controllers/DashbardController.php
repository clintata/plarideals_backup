<?php
session_start();
require_once __DIR__ . '/../models/Dashboard.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class DashbardController
{
    private $db;
    private $dashboard;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->dashboard = new Dashboard($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function readCountConsumer()
    {
        $stmt = $this->dashboard->readCountConsumer();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readConsumerFeedback()
    {
        $stmt = $this->dashboard->readConsumerFeedback();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readAppFeedback()
    {
        $stmt = $this->dashboard->readAppFeedback();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountComplaint()
    {
        $stmt = $this->dashboard->readCountComplaint();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountAnnouncement()
    {
        $stmt = $this->dashboard->readCountAnnouncement();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountTask()
    {
        $stmt = $this->dashboard->readCountTask();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountBilling()
    {
        $stmt = $this->dashboard->readCountBilling();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountUnpaid()
    {
        $stmt = $this->dashboard->readCountUnpaid();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountCollectable()
    {
        $stmt = $this->dashboard->readCountCollectable();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function readCountCurrentMeter($id)
    {
        $stmt = $this->dashboard->readCountCurrentMeter($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' =>  $id]);
        }
    }
    
    public function readCountUnpaidBill($id)
    {
        $stmt = $this->dashboard->readCountUnpaidBill($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readCountConsumtion($id)
    {
        $stmt = $this->dashboard->readCountConsumtion($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readDueDate($id)
    {
        $stmt = $this->dashboard->readDueDate($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readCountAnnounce($id)
    {
        $stmt = $this->dashboard->readCountAnnounce($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readAnnounce($id)
    {
        $stmt = $this->dashboard->readAnnounce($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readCountComplaintNoti($id)
    {
        $stmt = $this->dashboard->readCountComplaintNoti($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function readAnnounceComplaint($id)
    {
        $stmt = $this->dashboard->readAnnounceComplaint($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readCountConNoti($id)
    {
        $stmt = $this->dashboard->readCountConNoti($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readNotiCon($id)
    {
        $stmt = $this->dashboard->readNotiCon($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readAdminDash()
    {
        $stmt = $this->dashboard->readAdminDash();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readConsumerDash()
    {
        $id = $_SESSION['user_id'] ?? '';
        $stmt = $this->dashboard->readConsumerDash($id);
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readBillerDash()
    {
        $stmt = $this->dashboard->readBillerDash();
        $feedbackbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($feedbackbases)) {
            echo json_encode($feedbackbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
}
?>
