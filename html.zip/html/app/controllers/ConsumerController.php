<?php
// app/controllers/UserController.php
require_once __DIR__ . '/../models/Consumer.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class ConsumerController
{
    private $db;
    private $consumer;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->consumer = new Consumer($this->db); // Ensure CompanyBase can handle mysqli connection
    }

    // GET /users
    public function read()
    {
        $stmt = $this->consumer->read();
        $companybases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($companybases)) {
            echo json_encode($companybases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readBill()
    {
        $stmt = $this->consumer->readBill();
        $companybases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($companybases)) {
            echo json_encode($companybases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    // POST /users
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->consumer->consumer_name = $_POST['consumer_name'];
        $this->consumer->email = $_POST['email'];
        $this->consumer->phone = $_POST['phone'];
        $this->consumer->password = $_POST['password'];
        $this->consumer->address = $_POST['address'] ?? '';
        $this->consumer->street = $_POST['street'] ?? '';
        $this->consumer->barangay = $_POST['barangay'] ?? '';
        if ($this->consumer->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'Consumer created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => $this->consumer));
            exit;
        }
    }

    // PUT /users
    public function update()
    {
        // Parse the PUT data
        $data = json_decode(file_get_contents('php://input'), true);

        // Set user properties using parsed data
        $this->consumer->consumer_name = $data['consumer_name'];
        $this->consumer->email = $data['email'];
        $this->consumer->phone = $data['phone'];
        $this->consumer->password = $data['password'];
        $this->consumer->address = $data['address'] ?? '';
        $this->consumer->street = $data['street'] ?? '';
        $this->consumer->barangay = $data['barangay'] ?? '';
        $this->consumer->consumer_id = $data['consumer_id'] ?? '';
        if ($this->consumer->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->consumer]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->consumer]);
            exit;
        }
    }

    // DELETE /users
    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->consumer->consumer_id = $data['id'] ?? '';

        if ($this->consumer->delete()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' => 'User deleted.']);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->consumer]);
            exit;
        }
    }
}
?>