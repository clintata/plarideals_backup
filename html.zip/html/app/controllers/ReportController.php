<?php
session_start();
require_once __DIR__ . '/../models/Reports.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class ReportController
{
    private $db;
    private $reports;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->reports = new Reports($this->db); // Ensure CompanyBase can handle mysqli connection
    }
    public function readAllBill($date_from , $date_to)
    {
        $stmt = $this->reports->readAllBill($date_from , $date_to );
        $reportsbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($reportsbases)) {
            echo json_encode(   $reportsbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readUnpaidBill($date_from , $date_to)
    {
        $stmt = $this->reports->readUnpaidBill($date_from , $date_to );
        $reportsbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($reportsbases)) {
            echo json_encode(   $reportsbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

    public function readPaidBill($date_from , $date_to)
    {
        $stmt = $this->reports->readPaidBill($date_from , $date_to );
        $reportsbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($reportsbases)) {
            echo json_encode(   $reportsbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    
    public function readComplaint($date_from , $date_to)
    {
        $stmt = $this->reports->readComplaint($date_from , $date_to );
        $reportsbases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($reportsbases)) {
            echo json_encode(   $reportsbases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }

}
?>
