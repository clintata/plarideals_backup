<?php
// app/controllers/UserController.php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../../processes/db.php'; // Include your connection function

class UserController
{
    private $db;
    private $user;

    public function __construct()
    {
        $this->db = connect_to_database(); // Use your mysqli connection
        $this->user = new User($this->db); // Ensure CompanyBase can handle mysqli connection
    }

    // GET /users
    public function read()
    {
        $stmt = $this->user->read();
        $companybases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($companybases)) {
            echo json_encode($companybases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    public function readpersonnel()
    {
        $stmt = $this->user->readpersonnel();
        $companybases = $stmt ? $stmt->fetch_all(MYSQLI_ASSOC) : [];
    
        if (!empty($companybases)) {
            echo json_encode($companybases);
        } else {
            echo json_encode(['message' => 'Not Found']);
        }
    }
    // POST /users
    public function create()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->user->fullName = $_POST['fullName'] ?? '';
        $this->user->email = $_POST['email'] ?? '';
        $this->user->password = $_POST['password'] ?? '';
        $this->user->usertype =   $_POST['usertype'] ?? '';
        $this->user->idNum =   $_POST['idNum'] ?? '';
        if ($this->user->create()) {
            ob_clean();
            echo json_encode(array('success' => true, 'message' => 'User created successfully.'));
            exit;
        } else {
            ob_clean();
            echo json_encode(array('success' => false, 'message' => 'User not created successfully.'));
            exit;
        }
    }

    // PUT /users
    public function update()
    {
        // Parse the PUT data
        $data = json_decode(file_get_contents('php://input'), true);

        // Set user properties using parsed data
        $this->user->idNum = $data['idNum'] ?? '';
        $this->user->fullName = $data['fullName'] ?? '';
        $this->user->email = $data['email'] ?? '';
        $this->user->password = $data['password'] ?? '';
        $this->user->usertype = $data['usertype'] ?? '';

        if ($this->user->update()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' =>$this->user]);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->user]);
            exit;
        }
    }

    // DELETE /users
    public function delete()
    {
        $data = json_decode(file_get_contents('php://input'), true);
        $this->user->idNum = $data['id'] ?? '';

        if ($this->user->delete()) {
            ob_clean();
            echo json_encode(['success' => true, 'message' => 'User deleted.']);
            exit;
        } else {
            ob_clean();
            echo json_encode(['success' => false, 'message' => $this->user]);
            exit;
        }
    }
}
?>