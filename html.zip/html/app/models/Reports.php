<?php
class Reports
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function readAllBill($date_from, $date_to)
    {
        // Base query
        $query = "SELECT  a.*, b.consumer_name  FROM bill a
        INNER JOIN consumer b ON a.cID = b.consumer_id
        INNER JOIN (
            SELECT cID, MAX(bNo) AS max_bNo
            FROM bill
            GROUP BY cID
        ) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo";

        // Add date range filtering if both dates are provided
        if ($date_from && $date_to) {
            $query .= " AND a.bill_date BETWEEN ? AND ?";
        }

        $query .= " ORDER BY a.bill_date DESC";

        // Prepare the statement
        if ($stmt = $this->conn->prepare($query)) {
            // Bind parameters if date range is provided
            if ($date_from && $date_to) {
                $stmt->bind_param("ss", $date_from, $date_to);
            }

            // Execute the query
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            // Check if there are results
            if ($result->num_rows > 0) {
                // Return all results as an array
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            // Output query error
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readUnpaidBill($date_from, $date_to)
    {
        // Base query
        $query = "SELECT  a.bNo,a.cID,a.amount,a.bill_date,a.cutting_date,a.`status`,a.paid_amount,a.previous_balance,a.previous_meter,a.current_meter,a.consumption,a.penalty, b.consumer_name, b.barangay, b.street  FROM bill a
        INNER JOIN consumer b ON a.cID = b.consumer_id
        INNER JOIN (
            SELECT cID, MAX(bNo) AS max_bNo
            FROM bill
            GROUP BY cID
        ) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo
                  WHERE a.status <> 'PAID'";

        // Add date range filtering if both dates are provided
        if ($date_from && $date_to) {
            $query .= " AND a.bill_date BETWEEN ? AND ?";
        }

        $query .= " ORDER BY a.bill_date DESC";

        // Prepare the statement
        if ($stmt = $this->conn->prepare($query)) {
            // Bind parameters if date range is provided
            if ($date_from && $date_to) {
                $stmt->bind_param("ss", $date_from, $date_to);
            }

            // Execute the query
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            // Check if there are results
            if ($result->num_rows > 0) {
                // Return all results as an array
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            // Output query error
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readPaidBill($date_from, $date_to)
    {
        // Base query
        $query = "SELECT  a.*, b.consumer_name  FROM bill a
        INNER JOIN consumer b ON a.cID = b.consumer_id
        INNER JOIN (
            SELECT cID, MAX(bNo) AS max_bNo
            FROM bill
            GROUP BY cID
        ) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo
                  WHERE a.status = 'PAID'";

        // Add date range filtering if both dates are provided
        if ($date_from && $date_to) {
            $query .= " AND a.bill_date BETWEEN ? AND ?";
        }

        $query .= " ORDER BY a.bill_date DESC";

        // Prepare the statement
        if ($stmt = $this->conn->prepare($query)) {
            // Bind parameters if date range is provided
            if ($date_from && $date_to) {
                $stmt->bind_param("ss", $date_from, $date_to);
            }

            // Execute the query
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            // Check if there are results
            if ($result->num_rows > 0) {
                // Return all results as an array
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            // Output query error
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readComplaint($date_from, $date_to)
    {
        // Base query
        $query = "SELECT a.*,b.consumer_name,c.fullName,c.usertype FROM complaint a LEFT JOIN consumer b ON a.cID = b.consumer_id 
        LEFT JOIN account c ON a.assigned_to = c.idNum WHERE a.status<> 'in-active'";

        // Add date range filtering if both dates are provided
        if ($date_from && $date_to) {
            $query .= " AND a.date_reference BETWEEN ? AND ?";
        }

        $query .= " ORDER BY a.date_reference DESC";

        // Prepare the statement
        if ($stmt = $this->conn->prepare($query)) {
            // Bind parameters if date range is provided
            if ($date_from && $date_to) {
                $stmt->bind_param("ss", $date_from, $date_to);
            }

            // Execute the query
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            // Check if there are results
            if ($result->num_rows > 0) {
                // Return all results as an array
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            // Output query error
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

}
?>