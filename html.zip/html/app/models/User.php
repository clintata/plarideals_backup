<?php
// app/models/User.php
session_start();
class User
{
    private $conn;
    private $table = 'account'; // Include the prefix
    public $idNum;
    public $fullName;
    public $email;
    public $password;
    public $usertype;
    public $image_path;


    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Get Users
    public function read()
    {

        $query = "SELECT * FROM {$this->table}";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    public function readpersonnel()
    {

        $query = "SELECT * FROM {$this->table} WHERE usertype = 'personnel'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    
    public function create()
    {
        $query = "INSERT INTO {$this->table}(idNum, fullName, email, password, usertype)
        VALUES (?, ?, ?, ?, ?);";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('sssss', $this->idNum, $this->fullName, $this->email, $this->password, $this->usertype);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Create Error: ' . $this->conn->error;
                }
            } else {
                echo 'Create Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }


   // Update User
    public function update()
    {
        $query = "UPDATE {$this->table} 
                  SET fullName = ?, email = ?, password = ?, usertype = ?
                  WHERE idNum = ?";
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('sssss', $this->fullName, $this->email, $this->password, $this->usertype ,$this->idNum);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Update Error: ' . $this->conn->error;
                }
            } else {
                echo 'Update Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    public function delete()
    {
        $query = "DELETE FROM {$this->table} WHERE idNum = ?";
        
        try {
            $stmt = $this->conn->prepare($query);
            
            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }
    
            $stmt->bind_param('i', $this->idNum);  
    
            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }
    
        return false;
    }
}
?>