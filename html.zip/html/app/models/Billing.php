<?php
class Billing
{
    private $conn;
    private $table = 'bill'; // Include the prefix
    public $bNo;
    public $cID;
    public $amount;
    public $bill_date;
    public $cutting_date;
    public $barangay;
    public $street;
    public $status;
    public $paid_amount;
    public $previous_balance;
    public $previous_meter;
    public $current_meter;
    public $consumption;
    public $penalty;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read()
    {
        $query = "SELECT  a.bNo,a.cID,a.amount,a.bill_date,a.cutting_date,a.`status`,a.paid_amount,a.previous_balance,a.previous_meter,a.current_meter,a.consumption,a.penalty, b.consumer_name, b.barangay, b.street  FROM bill a
        INNER JOIN consumer b ON a.cID = b.consumer_id
        INNER JOIN (
            SELECT cID, MAX(bNo) AS max_bNo
            FROM bill
            GROUP BY cID
        ) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo WHERE a.status = 'active' ORDER BY bill_date  DESC";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    public function readConsumer($id)
    {
        $query = "SELECT  a.bNo, a.cID, a.amount, a.bill_date, a.cutting_date, a.`status`, a.paid_amount,
    a.previous_balance, a.previous_meter, a.current_meter, a.consumption, a.penalty, b.consumer_name, b.barangay, b.street,
    CASE 
        WHEN a.status = 'PAID' THEN 'Connected'
        WHEN a.cutting_date < CURRENT_DATE THEN 'Disconnected'
        ELSE 'Connected'
    END AS activation
FROM 
    bill a
INNER JOIN 
    consumer b ON a.cID = b.consumer_id WHERE b.consumer_id = '$id' ORDER BY bill_date  DESC";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function create()
    {
        $query = "INSERT INTO {$this->table} 
                  (cID, amount, bill_date, cutting_date, barangay, street, status, previous_balance, previous_meter, current_meter, consumption, penalty)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt) {
                $status = 'active';
                $updated_balance = $this->previous_balance + $this->amount;
                $stmt->bind_param(
                    'sdsssssdiddi',
                    $this->cID,
                    $this->amount,
                    $this->bill_date,
                    $this->cutting_date,
                    $this->barangay,
                    $this->street,
                    $status,
                    $updated_balance,
                    $this->previous_meter,
                    $this->current_meter,
                    $this->consumption,
                    $this->penalty
                );

                // Execute and check for success
                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Execute Error: ' . $stmt->error;
                }
            } else {
                echo 'Prepare Error: ' . $this->conn->error;
            }
        } catch (mysqli_sql_exception $e) {
            echo 'Create Error: ' . $e->getMessage();
        }

        return false;
    }

    public function createNoti($id, $Message)
    {
        $query = "INSERT INTO notification
                  (consumer_id, Title, Message,date_reference)
                  VALUES ('$id', 'Billing', '$Message',NOW());";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt) {
                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Execute Error: ' . $stmt->error;
                }
            } else {
                echo 'Prepare Error: ' . $this->conn->error;
            }
        } catch (mysqli_sql_exception $e) {
            echo 'Create Error: ' . $e->getMessage();
        }

        return false;
    }

    public function update()
    {
        $query = "UPDATE {$this->table} 
                  SET cID = ?, amount = ?, bill_date = ?, cutting_date = ?, barangay = ?, previous_balance = ?, previous_meter = ?, current_meter = ?, consumption = ?, penalty = ?
                  WHERE bNo = ?";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt) {
                $updated_balance = $this->previous_balance + $this->amount;

                $stmt->bind_param(
                    'sdsdsdiddi',
                    $this->cID,
                    $this->amount,
                    $this->bill_date,
                    $this->cutting_date,
                    $this->barangay,
                    $updated_balance,
                    $this->previous_meter,
                    $this->current_meter,
                    $this->consumption,
                    $this->penalty,
                    $this->bNo
                );

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Execute Error: ' . $stmt->error;
                }
            } else {
                echo 'Prepare Error: ' . $this->conn->error;
            }
        } catch (mysqli_sql_exception $e) {
            echo 'Update Error: ' . $e->getMessage();
        }

        return false;
    }


    public function updatePaid()
    {
        $query = "UPDATE {$this->table} 
                  SET paid_amount = ?, 
                      previous_balance = previous_balance - ?, 
                      status = 'PAID'
                  WHERE bNo = ?";
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt) {
                // Bind parameters using bind_param()
                $stmt->bind_param('sss', $this->paid_amount, $this->paid_amount, $this->bNo);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Update Error: ' . $this->conn->error;
                }
            } else {
                echo 'Update Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }
    public function delete()
    {
        $query = "UPDATE {$this->table}    SET status = 'in-active' WHERE bNo = ?";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }

            $stmt->bind_param('i', $this->bNo);

            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }

        return false;
    }


}
?>