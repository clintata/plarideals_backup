<?php
// app/models/User.php
session_start();
class Consumer
{
    private $conn;
    private $table = 'consumer'; // Include the prefix
    public $keyctr;
    public $consumer_id;
    public $consumer_name;
    public $email;
    public $phone;
    public $password;
    public $status;
    public $date_reference;
    public $address;
    public $street;
    public $barangay;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Get Users
    public function read()
    {

        $query = "SELECT * FROM {$this->table} WHERE status = 'active'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readBill()
    {
        $query = "SELECT *
        FROM consumer b
        LEFT JOIN (
            SELECT a.bNo,a.cID,a.amount,a.bill_date,a.cutting_date,a.paid_amount,a.previous_balance,a.previous_meter,a.current_meter,a.consumption,a.penalty, max_bill.max_bNo
            FROM bill a
            INNER JOIN (
                SELECT cID, MAX(bNo) AS max_bNo
                FROM bill
                GROUP BY cID
            ) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo
        ) AS latest_bill ON b.consumer_id = latest_bill.cID
        WHERE b.status = 'active'
        ORDER BY latest_bill.bNo DESC;
        ";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    public function create()
    {
        $query = "CALL sp_insert_consumer(?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt) {
                // Set date reference to current date if not set
                $date_reference = $this->date_reference ?? date('Y-m-d');

                // Bind parameters in the order defined in the stored procedure
                $stmt->bind_param(
                    'ssssssss',
                    $this->consumer_name,
                    $this->email,
                    $this->phone,
                    $this->password,
                    $date_reference,
                    $this->address,
                    $this->street,
                    $this->barangay
                );

                if ($stmt->execute()) {
                    // Since the procedure is inserting data, check the affected rows instead of using get_result()
                    if ($stmt->affected_rows > 0) {
                        // Assuming consumer_id was set via the procedure, no need to fetch it with get_result()
                        $stmt->close();
                        return [
                            'success' => true,
                            'message' => 'Consumer created successfully'
                        ];
                    } else {
                        throw new Exception("Insert failed, no rows affected.");
                    }
                } else {
                    throw new Exception("Execute failed: " . $stmt->error);
                }
            } else {
                throw new Exception("Prepare failed: " . $this->conn->error);
            }
        } catch (Exception $e) {
            error_log("Create Consumer Error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage() // Return the error message
            ];
        }
    }

    // Update User
    public function update()
    {
        $query = "UPDATE {$this->table} 
                  SET consumer_name = ?, email = ?, phone = ?, password = ?, address = ?, street = ?, barangay = ?
                  WHERE consumer_id = ?";
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param(
                    'ssssssss',
                    $this->consumer_name,
                    $this->email,
                    $this->phone,
                    $this->password,
                    $this->address,
                    $this->street,
                    $this->barangay,
                    $this->consumer_id
                );

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Update Error: ' . $this->conn->error;
                }
            } else {
                echo 'Update Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    public function delete()
    {
        $query = "UPDATE {$this->table} 
                  SET status = 'in-active' WHERE consumer_id = ?";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }

            $stmt->bind_param('s', $this->consumer_id);

            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }

        return false;
    }
}
?>