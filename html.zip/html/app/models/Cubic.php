<?php
class Cubic
{
    private $conn;
    private $table = 'cubic'; // Include the prefix
    public $keyctr;
    public $cubic;
    public $default_amount;
    public $first_rate;
    public $second_rate;
    public $third_rate;
    public $first_penalty;
    public $second_penalty;
    public $third_penalty;
    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read()
    {
        $query = "SELECT * FROM {$this->table}";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    // Create User

    public function update()
    {
        $query = "UPDATE {$this->table} 
                  SET cubic = ?, default_amount = ?, first_rate = ?, second_rate = ? , third_rate = ?, first_penalty = ?, second_penalty = ? , third_penalty = ?
                  WHERE keyctr = ?";
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('sssssssss', $this->cubic, $this->default_amount, $this->first_rate, $this->second_rate, $this->third_rate, $this->first_penalty, $this->second_penalty, $this->third_penalty, $this->keyctr);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Update Error: ' . $this->conn->error;
                }
            } else {
                echo 'Update Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

}
?>