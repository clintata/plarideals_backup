<?php
class Dashboard
{
    private $conn;

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function readCountConsumer()
    {
        $query = "SELECT COUNT(*) as counttotal FROM `consumer` WHERE `status` = 'ACTIVE' OR `status` = 'active'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readConsumerFeedback()
    {
        $query = "SELECT COUNT(*) AS counttotal 
        FROM consumerfeedback WHERE date = CURRENT_DATE;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readAppFeedback()
    {
        $query = "SELECT COUNT(*) AS counttotal 
        FROM feedback WHERE date = CURRENT_DATE;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountComplaint()
    {
        $query = "SELECT COUNT(*) AS counttotal 
        FROM complaint WHERE date_reference = CURRENT_DATE;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountAnnouncement()
    {
        $query = "SELECT COUNT(*) AS counttotal 
        FROM announcement WHERE date = CURRENT_DATE;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountTask()
    {
        $query = "SELECT COUNT(*) AS counttotal 
        FROM task WHERE status = 'pending';";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountBilling()
    {
        $query = "SELECT COUNT(*) as counttotal FROM `consumer` WHERE `status` = 'ACTIVE' OR `status` = 'active';";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountUnpaid()
    {
        $query = "SELECT COUNT(*) as counttotal FROM `consumer` WHERE `status` = 'ACTIVE' OR `status` = 'active';";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountCollectable()
    {
        $query = "SELECT SUM(amount) as counttotal FROM bill WHERE `status` <> 'PAID';";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountCurrentMeter($id)
    {
        $query = "SELECT current_meter FROM bill WHERE cID = '$id' ORDER BY bill_date DESC limit 1;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountUnpaidBill($id)
    {
        $query = "SELECT previous_balance FROM bill WHERE cID = '$id' ORDER BY bill_date DESC limit 1;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountConsumtion($id)
    {
        $query = "SELECT consumption FROM bill WHERE cID = '$id' ORDER BY bill_date DESC;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readDueDate($id)
    {
        $query = "SELECT bill_date FROM bill WHERE cID = '$id' ORDER BY bill_date DESC;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountAnnounce($id)
    {
        $query = "SELECT COUNT(*) as counttotal
        FROM announcement a
        WHERE NOT EXISTS (
            SELECT 1 
            FROM user_deleted_announcements b 
            WHERE a.aID = b.announcement_id
            AND b.idNum = '$id'
        );";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    public function readAnnounce($id)
    {
        $query = "SELECT title, message, date, false as status, aID 
        FROM announcement
        WHERE aID NOT IN (
            SELECT aID 
            FROM announcement a
            WHERE NOT EXISTS (
                SELECT 1 
                FROM user_deleted_announcements b 
                WHERE a.aID = b.announcement_id 
                AND b.idNum = '$id'
            )
        )
        UNION 
        SELECT title, message, date, true as status, a.aID 
        FROM announcement a
        WHERE NOT EXISTS (
            SELECT 1 
            FROM user_deleted_announcements b 
            WHERE a.aID = b.announcement_id
            AND b.idNum = '$id'
        )ORDER BY status DESC, date DESC;;
        ";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountComplaintNoti($id)
    {
        $query = "SELECT COUNT(*) AS counttotal
        FROM complaint a
        WHERE NOT EXISTS (
            SELECT 1 
            FROM user_deleted_complaint b 
            WHERE a.cpID = b.announcement_id
        AND b.idNum = '$id'
        );";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readAnnounceComplaint($id)
    {
        $query = "SELECT  consumer_name ,message, a.date_reference, false as statuss, cpID 
        FROM complaint a INNER JOIN consumer b on a.cID = b.consumer_id
        WHERE cpID NOT IN (
            SELECT cpID 
            FROM complaint a
            WHERE NOT EXISTS (
                SELECT 1 
                FROM user_deleted_complaint b 
                WHERE a.cpID = b.announcement_id
                  AND b.idNum = '$id' 
            )
        )
        UNION 
        SELECT  consumer_name ,message, a.date_reference, false as statuss, cpID 
        FROM complaint a INNER JOIN consumer b on a.cID = b.consumer_id
        WHERE NOT EXISTS (
            SELECT 1 
            FROM user_deleted_complaint b 
            WHERE a.cpID = b.announcement_id 
            AND b.idNum = '$id'
        )ORDER BY statuss DESC, date_reference DESC;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readCountConNoti($id)
    {
        $query = "SELECT COUNT(*) AS counttotal
                  FROM notification 
                  WHERE MONTH(date_reference) = MONTH(NOW()) 
                  AND consumer_id = '$id'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readNotiCon($id)
    {
        $query = "SELECT *
        FROM notification WHERE MONTH(date_reference) = MONTH(NOW())  AND consumer_id = '$id'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }


    public function readAdminDash()
    {
        $query = "SELECT 
    m.month_number,
    m.month_name,
    COALESCE(SUM(CASE WHEN b.status = 'PAID' THEN b.amount ELSE 0 END), 0) AS total_paid,
    COALESCE(SUM(CASE WHEN b.status <> 'PAID' THEN b.amount ELSE 0 END), 0) AS total_unpaid
FROM 
    (SELECT 1 AS month_number, 'January' AS month_name UNION ALL
     SELECT 2, 'February' UNION ALL
     SELECT 3, 'March' UNION ALL
     SELECT 4, 'April' UNION ALL
     SELECT 5, 'May' UNION ALL
     SELECT 6, 'June' UNION ALL
     SELECT 7, 'July' UNION ALL
     SELECT 8, 'August' UNION ALL
     SELECT 9, 'September' UNION ALL
     SELECT 10, 'October' UNION ALL
     SELECT 11, 'November' UNION ALL
     SELECT 12, 'December') AS m
LEFT JOIN bill AS b 
    ON EXTRACT(MONTH FROM b.bill_date) = m.month_number
GROUP BY 
    m.month_number, m.month_name
ORDER BY 
    m.month_number;
";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readConsumerDash($id)
    {
        $query = "SELECT 
            m.month_number,
            m.month_name,
            COALESCE(SUM(b.consumption), 0) AS consumption
        FROM 
            (SELECT 1 AS month_number, 'January' AS month_name UNION ALL
             SELECT 2, 'February' UNION ALL
             SELECT 3, 'March' UNION ALL
             SELECT 4, 'April' UNION ALL
             SELECT 5, 'May' UNION ALL
             SELECT 6, 'June' UNION ALL
             SELECT 7, 'July' UNION ALL
             SELECT 8, 'August' UNION ALL
             SELECT 9, 'September' UNION ALL
             SELECT 10, 'October' UNION ALL
             SELECT 11, 'November' UNION ALL
             SELECT 12, 'December') AS m
        LEFT JOIN bill AS b 
            ON EXTRACT(MONTH FROM b.bill_date) = m.month_number WHERE b.cID = '$id'
        GROUP BY 
            m.month_number, m.month_name
        ORDER BY 
            m.month_number;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readBillerDash()
    {
        $query = "SELECT 
    m.month_number,
    m.month_name,
    COALESCE(SUM(CASE WHEN b.status = 'PAID' THEN 1 ELSE 0 END), 0) AS total_paid,
    COALESCE(SUM(CASE WHEN b.status <> 'PAID' THEN 1 ELSE 0 END), 0) AS total_unpaid
FROM 
    (SELECT 1 AS month_number, 'January' AS month_name UNION ALL
     SELECT 2, 'February' UNION ALL
     SELECT 3, 'March' UNION ALL
     SELECT 4, 'April' UNION ALL
     SELECT 5, 'May' UNION ALL
     SELECT 6, 'June' UNION ALL
     SELECT 7, 'July' UNION ALL
     SELECT 8, 'August' UNION ALL
     SELECT 9, 'September' UNION ALL
     SELECT 10, 'October' UNION ALL
     SELECT 11, 'November' UNION ALL
     SELECT 12, 'December') AS m
LEFT JOIN bill AS b 
    ON EXTRACT(MONTH FROM b.bill_date) = m.month_number
GROUP BY 
    m.month_number, m.month_name
ORDER BY 
    m.month_number;";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
}
?>