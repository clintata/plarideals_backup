<?php
class Complaint
{
    private $conn;
    private $table = 'complaint'; // Include the prefix
    public $cpID;
    public $cID;
    public $message;
    public $note;
    public $status;
    public $assigned_to;
    public $role;
    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read()
    {
        $query = "SELECT a.*,b.consumer_name,c.fullName,c.usertype FROM {$this->table} a LEFT JOIN consumer b ON a.cID = b.consumer_id LEFT JOIN account c ON a.assigned_to = c.idNum WHERE a.status<> 'in-active' ";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readConsumer($id)
    {
        $query = "SELECT a.*,b.consumer_name,c.fullName,c.usertype FROM {$this->table} a LEFT JOIN consumer b ON a.cID = b.consumer_id LEFT JOIN account c ON a.assigned_to = c.idNum WHERE a.status<> 'in-active' AND b.consumer_id = '$id'";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    // Create User
    public function create()
    {
        $query = "INSERT INTO {$this->table}(cID, message, note, status, assigned_to, role, date_reference)
        VALUES (?, ?, ?, ?, ?, ?, NOW())";

        try {
            $stmt = $this->conn->prepare($query);
            $this->status = 'pending';
            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('ssssss', $this->cID, $this->message, $this->note, $this->status, $this->assigned_to, $this->role);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Create Error: ' . $this->conn->error;
                }
            } else {
                echo 'Create Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    public function update()
    {
        $query = "UPDATE {$this->table} 
                  SET cID = ?, message = ?, assigned_to = ?, role = ?, note = ? 
                  WHERE cpID = ?";
        try {
            $stmt = $this->conn->prepare($query);

            // Bind parameters using bind_param()
            // 'ssssss' because we have 6 string parameters
            $stmt->bind_param(
                'ssssss',
                $this->cID,
                $this->message,
                $this->assigned_to,
                $this->role,
                $this->note,
                $this->cpID
            );

            if ($stmt->execute()) {
                return true;
            }

            echo 'Update Error: ' . $this->conn->error;
            return false;

        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
            return false;
        }
    }


    public function updateComplaint()
    {
        $query = "UPDATE {$this->table} 
                  SET cID = ?, message = ?, note = ? 
                  WHERE cpID = ?";
        try {
            $stmt = $this->conn->prepare($query);

            // Bind parameters using bind_param()
            // 'ssssss' because we have 6 string parameters
            $stmt->bind_param(
                'ssss',
                $this->cID,
                $this->message,
                $this->note,
                $this->cpID
            );

            if ($stmt->execute()) {
                return true;
            }

            echo 'Update Error: ' . $this->conn->error;
            return false;

        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
            return false;
        }
    }
    public function delete()
    {
        $query = "UPDATE {$this->table} 
                  SET status = 'in-active' WHERE cpID = ?";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }

            $stmt->bind_param('s', $this->cpID);

            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }

        return false;
    }


}
?>