<?php
class AnnouncementBase
{
    private $conn;
    private $table = 'announcement'; // Include the prefix
    public $aID;
    public $title;
    public $message;
    public $date;
    public $posted_by;
    public $atype;
    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read()
    {
        $query = "SELECT * FROM {$this->table}";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set
    
            if ($result->num_rows > 0) {
                // Fetch all results
               return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }
    
    // Create User
    public function create()
    {
        $query = "INSERT INTO {$this->table}(title, message, date, posted_by, atype)
        VALUES (?, ?, ?, ?, ?);";
    
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('sssss', $this->title, $this->message, $this->date, $this->posted_by, $this->atype);
    
                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Create Error: ' . $this->conn->error;
                }
            } else {
                echo 'Create Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    public function createNoti($aID,$announcement_id)
    {
        $query = "INSERT INTO user_deleted_announcements (idNum, announcement_id)
        VALUES (?, ?);";
    
        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('ss', $aID, $announcement_id);
    
                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Create Error: ' . $this->conn->error;
                }
            } else {
                echo 'Create Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    // Update User

    // Delete User
    public function delete()
    {
        $query = "DELETE FROM {$this->table} WHERE aID = ?";
        
        try {
            $stmt = $this->conn->prepare($query);
            
            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }
    
            $stmt->bind_param('i', $this->aID);  
    
            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }
    
        return false;
    }
    
    
}
?>