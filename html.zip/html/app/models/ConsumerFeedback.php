<?php
class ConsumerFeedback
{
    private $conn;
    private $table = 'consumerfeedback'; // Include the prefix
    public $fID;
    public $idNum;
    public $message;
    public $date;
    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function read()
    {
        $query = "SELECT * FROM {$this->table} ORDER BY date";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    public function readConsumer($id)
    {
        $query = "SELECT * FROM {$this->table} WHERE idNum = '$id' ORDER BY date";
        if ($stmt = $this->conn->prepare($query)) {
            $stmt->execute();
            $result = $stmt->get_result(); // Get the result set

            if ($result->num_rows > 0) {
                // Fetch all results
                return $result;
            } else {
                echo json_encode(['message' => 'No data found']);
            }
        } else {
            echo json_encode(['message' => 'Query Error: ' . $this->conn->error]);
        }
    }

    // Create User
    public function create()
    {
        $query = "INSERT INTO {$this->table}(idNum, message, date)
        VALUES (?, ?, NOW());";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt = $this->conn->prepare($query)) {
                // Bind parameters using bind_param()
                $stmt->bind_param('ss', $this->fID, $this->message);

                if ($stmt->execute()) {
                    return true;
                } else {
                    echo 'Create Error: ' . $this->conn->error;
                }
            } else {
                echo 'Create Error: ' . $this->conn->error;
            }
            return false;
        } catch (PDOException $e) {
            echo 'Create Error: ' . $e->getMessage();
        }
        return false;
    }

    // Delete User
    public function delete()
    {
        $query = "DELETE FROM {$this->table} WHERE fID = ?";

        try {
            $stmt = $this->conn->prepare($query);

            if ($stmt === false) {
                throw new Exception('Statement preparation failed: ' . $this->conn->error);
            }

            $stmt->bind_param('i', $this->fID);

            if ($stmt->execute()) {
                return true;
            } else {
                throw new Exception('Execution failed: ' . $stmt->error);
            }
        } catch (Exception $e) {
            echo 'Delete Error: ' . $e->getMessage();
        }

        return false;
    }

}
?>