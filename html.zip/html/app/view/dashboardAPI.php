<?php
// index.php

require_once __DIR__ . '/../controllers/DashbardController.php';

$controller = new DashbardController();

$request_method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Assuming your script is located at /LineOne/app/view/userAPI.php
// Remove everything before the relevant segment
$base_path = '/app/view/dashboardAPI.php';
$path = str_replace($base_path, '', $path);
// Trim any extra slashes
$path = rtrim($path, '/');

switch ($path) {
    case '/dashboard':
        if ($request_method == 'GET') {
            $action = $_GET['action'] ?? null;
            $id = $_GET['userid'] ?? null;
            if ($action == 'readCountConsumer') {
                $controller->readCountConsumer();
            } elseif ($action == 'readConsumerFeedback') {
                $controller->readConsumerFeedback();
            } elseif ($action == 'readAppFeedback') {
                $controller->readAppFeedback();
            } elseif ($action == 'readCountComplaint') {
                $controller->readCountComplaint();
            } elseif ($action == 'readCountAnnouncement') {
                $controller->readCountAnnouncement();
            } elseif ($action == 'readCountTask') {
                $controller->readCountTask();
            } elseif ($action == 'readCountBilling') {
                $controller->readCountBilling();
            } elseif ($action == 'readCountUnpaid') {
                $controller->readCountUnpaid();
            } elseif ($action == 'readCountCollectable') {
                $controller->readCountCollectable();
            } elseif ($action == 'CurrentMeter') {
                $controller->readCountCurrentMeter($id);
            } elseif ($action == 'readCountUnpaidBill') {
                $controller->readCountUnpaidBill($id);
            } elseif ($action == 'readCountConsumtion') {
                $controller->readCountConsumtion($id);
            } elseif ($action == 'readDueDate') {
                $controller->readDueDate($id);
            } elseif ($action == 'readCountAnnounce') {
                $controller->readCountAnnounce($id);
            } elseif ($action == 'readAnnounce') {
                $controller->readAnnounce($id);
            } elseif ($action == 'readCountComplaintNoti') {
                $controller->readCountComplaintNoti($id);
            } elseif ($action == 'readAnnounceComplaint') {
                $controller->readAnnounceComplaint($id);
            } elseif ($action == 'readCountConNoti') {
                $controller->readCountConNoti($id);
            } elseif ($action == 'readNotiCon') {
                $controller->readNotiCon($id);
            } elseif ($action == 'readAdminDash') {
                $controller->readAdminDash();
            } elseif ($action == 'readConsumerDash') {
                $controller->readConsumerDash();
            } elseif ($action == 'readBillerDash') {
                $controller->readBillerDash();
            }
            
        } else {
            http_response_code(405); // Method Not Allowed
            echo json_encode(['message' => 'Method Not Allowed']);
        }
        break;
    default:
        http_response_code(404); // Not Found
        echo json_encode(['message' => 'Not Found']);
        break;
}



?>