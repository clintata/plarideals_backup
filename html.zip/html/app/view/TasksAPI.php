<?php
// index.php

require_once __DIR__ . '/../controllers/TasksController.php';

$controller = new TasksController();

$request_method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Assuming your script is located at /LineOne/app/view/userAPI.php
// Remove everything before the relevant segment
$base_path = '/app/view/TasksAPI.php';
$path = str_replace($base_path, '', $path);
// Trim any extra slashes
$path = rtrim($path, '/');

switch ($path) {
    case '/tasks':
        if ($request_method == 'GET') {
            $controller->read();
        } elseif ($request_method == 'POST') {
            $controller->create();
        } elseif ($request_method == 'PUT') {
            $controller->update();
        } elseif ($request_method == 'DELETE') {
            $controller->delete();
        } else {
            http_response_code(405); // Method Not Allowed
            echo json_encode(['message' => 'Method Not Allowed']);
        }
        break;
    default:
        http_response_code(404); // Not Found
        echo json_encode(['message' => 'Not Found']);
        break;
}



?>