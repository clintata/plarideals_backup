<?php
// index.php

require_once __DIR__ . '/../controllers/ConsumerController.php';
$logfile = 'debug.txt';
$controller = new ConsumerController();

$request_method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Assuming your script is located at /LineOne/app/view/userAPI.php
// Remove everything before the relevant segment
$base_path = '/app/view/consumerAPI.php';
$path = str_replace($base_path, '', $path);

// echo "<script>alert(\"" + (string)$path  + "\")</script>";
// Trim any extra slashes
$path = rtrim($path, '/');
switch ($path) {
    case '/consumer':
        if ($request_method == 'GET') {
            $action = $_GET['action'] ?? null;
            if ($action == 'consumerbill') {
                $controller->readBill();
            } else {
                $controller->read();
            }
        } elseif ($request_method == 'POST') {
            file_put_contents($logfile, $request_method, FILE_APPEND);
            $controller->create();
        } elseif ($request_method == 'PUT') {
            $controller->update();
        } elseif ($request_method == 'DELETE') {
            $controller->delete();
        } else {
            http_response_code(405); // Method Not Allowed
            echo json_encode(['message' => 'Method Not Allowed']);
        }
        break;
    default:
        http_response_code(404); // Not Found
        echo json_encode(['message' => 'Not Found']);
        break;
}