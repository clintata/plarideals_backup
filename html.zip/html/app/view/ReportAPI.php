<?php
// index.php

require_once __DIR__ . '/../controllers/ReportController.php';

$controller = new ReportController();

$request_method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Assuming your script is located at /LineOne/app/view/userAPI.php
// Remove everything before the relevant segment
$base_path = '/app/view/ReportAPI.php';
$path = str_replace($base_path, '', $path);

// Trim any extra slashes
$path = rtrim($path, '/');
switch ($path) {
    case '/report':
        if ($request_method == 'GET') {
            $action = $_GET['action'] ?? null;
            $date_from = $_GET['date_from'] ?? null;
            $date_to = $_GET['date_to'] ?? null;
            if ($action == 'billReportAll') {
                $controller->readAllBill($date_from, $date_to);
            } elseif ($action == 'readUnpaidBill') {
                $controller->readUnpaidBill($date_from, $date_to);
            } elseif ($action == 'readPaidBill') {
                $controller->readPaidBill($date_from, $date_to);
            } elseif ($action == 'readComplaint') {
                $controller->readComplaint($date_from, $date_to);
            }  else{
                http_response_code(405); // Method Not Allowed
                echo json_encode(['message' => 'Method Not Allowed']);
            }

        } else {
            http_response_code(405); // Method Not Allowed
            echo json_encode(['message' => 'Method Not Allowed']);
        }
        break;
    default:
        http_response_code(404); // Not Found
        echo json_encode(['message' => 'Not Found']);
        break;
}
?>