<?php
include 'db.php';

// Create connection
$conn = connect_to_database();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $id_number = mysqli_real_escape_string($conn, $_POST['id-number']);
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $utype = 'consumer';

    // Optionally hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if email or ID already exists
    $check_query = "SELECT * FROM account WHERE email='$email' OR idNum='$id_number' LIMIT 1";
    $result = $conn->query($check_query);

    if ($result->num_rows > 0) {
        echo "<script>alert('Email already exist!'); window.location.href = '../register.php';</script>";
    } else {
        // Insert data into the 'account' table
        $sql = "INSERT INTO account (idNum, fullName, email, password,usertype) VALUES ('$id_number', '$fullname', '$email', '$password', '$utype')";

        if ($conn->query($sql) === TRUE) {
            // Display an alert dialog and redirect to index.php
            echo "<script>alert('Account registered successfully!'); window.location.href = '../index.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>