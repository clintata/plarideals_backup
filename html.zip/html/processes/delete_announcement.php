<?php
include 'db.php';

// Check if aID is set in the URL
if (isset($_GET['aID'])) {
    // Get the announcement ID from the URL
    $aID = $_GET['aID'];

    // Create connection
    $conn = connect_to_database();

    // Prepare and execute SQL query to delete the announcement
    $sql = "DELETE FROM announcement WHERE aID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $aID);

    if ($stmt->execute()) {
        echo "Announcement deleted successfully.";
    } else {
        echo "Error deleting announcement.";
    }

    // Close the connection
    $stmt->close();
    $conn->close();
} else {
    echo "No announcement selected for deletion.";
    exit;
}

// Redirect back to the announcements page after deletion
header("Location: ../admin/see_announcements.php");
exit;
?>
