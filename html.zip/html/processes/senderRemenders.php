<?php

// Function to send SMS
function SendMessages($number, $message)
{
    $ch = curl_init();
    $parameters = array(
        'apikey' => '66685d96a2d76d4414344a11f6b013f6', // Your API KEY
        'number' => $number,
        'message' => $message,
        'sendername' => 'PlariDeals'
    );

    curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $output = curl_exec($ch);

    if ($output === false) {
        $error = 'cURL Error: ' . curl_error($ch);
        curl_close($ch);
        return ['status' => 'Failed', 'error' => $error];
    }

    curl_close($ch);

    // Decode API response
    $decodedOutput = json_decode($output, true);

    // If decoding fails, return an error
    if (!is_array($decodedOutput)) {
        return ['status' => 'Failed', 'error' => 'Invalid response from API'];
    }

    return $decodedOutput; // Return the decoded API response
}

$number = $_POST['number'] ?? 'recipient_number';
$message = $_POST['message'] ?? 'Your message content';

// Call the SendMessages function and capture the response
$response = SendMessages($number, $message);

?>
