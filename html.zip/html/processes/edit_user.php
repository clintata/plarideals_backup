<?php
include 'db.php';

// Check if idNum is set in the URL
if (isset($_GET['idNum'])) {
    // Get the user's idNum from the URL
    $idNum = $_GET['idNum'];

    // Create connection
    $conn = connect_to_database();

    // Prepare SQL query to fetch user data by idNum
    $sql = "SELECT fullName, email, password, usertype FROM account WHERE idNum = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idNum);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "User not found.";
        exit;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "No user selected for editing.";
    exit;
}

// If the form is submitted, process the update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];

    // Prepare and execute the update query
    $sql = "UPDATE account SET fullName = ?, email = ?, password = ?, usertype = ? WHERE idNum = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $fullName, $email, $password, $usertype, $idNum);

    if ($stmt->execute()) {
        echo "User updated successfully.";
    } else {
        echo "Error updating user.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Redirect to the users list or some other page
    header("Location: ../admin/see_users.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
</head>
<body>

<h1>Edit User</h1>

<form method="POST" action="">
    <label for="fullName">Full Name:</label>
    <input type="text" id="fullName" name="fullName" value="<?php echo htmlspecialchars($row['fullName']); ?>" required><br><br>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required><br><br>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($row['password']); ?>" required><br><br>

    <label for="usertype">User Type:</label>
    <select id="usertype" name="usertype" required>
        <option value="admin" <?php if ($row['usertype'] == 'admin') echo 'selected'; ?>>Admin</option>
        <option value="biller" <?php if ($row['usertype'] == 'biller') echo 'selected'; ?>>Biller</option>
        <option value="field_personnel" <?php if ($row['usertype'] == 'field_personnel') echo 'selected'; ?>>Field Personnel</option>
        <option value="consumer" <?php if ($row['usertype'] == 'consumer') echo 'selected'; ?>>Consumer</option>
    </select><br><br>

    <input type="submit" value="Update User">
</form>
<a href="../admin/see_users.php">Back</a>
</body>
</html>
