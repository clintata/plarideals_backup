<?php
session_start();
include 'db.php';

$conn = connect_to_database();

if ($conn->connect_error) {
    $_SESSION['error_message'] = "Database connection failed.";
    header("Location: ../login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT idNum, fullName, email, usertype, password FROM account WHERE email = ?
        UNION
        SELECT consumer_id AS idNum, consumer_name AS fullName, email, 'consumer' AS usertype, password 
        FROM consumer WHERE email = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if ($password == $user['password']) {
            $_SESSION['user_id'] = $user['idNum'];
            $_SESSION['fullname'] = $user['fullName'];
            $_SESSION['usertype'] = $user['usertype'];

            switch ($user['usertype']) {
                case 'admin':
                    header("Location: ../AdminDashboard/index.php");
                    break;
                case 'biller':
                    header("Location: ../BillingDashboard/index.php");
                    break;
                case 'cashier':
                    header("Location: ../CashierDashboard/index.php");
                    break;
                case 'consumer':
                    header("Location: ../ConsumerDashboard/index.php");
                    break;
                default:
                    $_SESSION['error_message'] = "Invalid user type.";
                    header("Location: ../index.php");
            }
            exit();
        } else {
            $_SESSION['error_message'] = "Invalid password.";
            header("Location: ../index.php");
            exit();
        }
    } else {
        $_SESSION['error_message'] = "No account found with this email.";
        header("Location: ../index.php");
        exit();
    }
}

$conn->close();
?>
