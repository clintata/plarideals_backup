<?php
require_once 'db.php';

// Function to send SMS
function SendMessage($id, $message)
{
    $conn = connect_to_database();

    // Prepare the SQL SELECT statement to check if the phone number exists in the consumer table
    $stmt = $conn->prepare("SELECT phone FROM consumer WHERE consumer_id = ?");
    if (!$stmt) {
        echo "SQL preparation error: " . $conn->error;
        return;
    }

    // Bind the consumer_id parameter
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a row was found
    if ($result->num_rows === 0) {
        echo "Consumer not found!";
        return;
    }

    // Fetch the phone number from the result
    $row = $result->fetch_assoc();
    $phone = $row['phone'];

    // Send SMS via Semaphore API
    $ch = curl_init();
    $parameters = array(
        'apikey' => '66685d96a2d76d4414344a11f6b013f6', // Your API KEY
        'number' => $phone,
        'message' => $message,
        'sendername' => 'PlariDeals'
    );

    curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $output = curl_exec($ch);

    if ($output === false) {
        echo 'cURL Error: ' . curl_error($ch);
    } else {
        echo "Response from Semaphore API: " . $output . "<br>";
    }

    curl_close($ch);
}

$number = $_POST['number'] ?? 'recipient_number';
$message = $_POST['message'] ?? 'Your message content';

?>
