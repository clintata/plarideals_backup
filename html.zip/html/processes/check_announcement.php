<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['fullname'])) {
    die("You must be logged in to post an announcement.");
}

// Database connection details
include 'db.php';

// Create connection
$conn = connect_to_database();

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $atype = mysqli_real_escape_string($conn, $_POST['atype']);
    $posted_by = $_SESSION['fullname']; // Get the name of the user who is logged in

    // Insert data into the 'announcement' table
    $sql = "INSERT INTO announcement (title, message, date, posted_by,atype) VALUES ('$title', '$message', '$date', '$posted_by','$atype')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('announcement added successfully!'); window.location.href = '../admin/see_announcements.php';</script>";
        // Optionally, redirect to another page
        // header('Location: announcements.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
