<?php
define('API_URL', 'https://plarideals.mooo.com/plarideals/app/view/');
function connect_to_database() {
    // Database connection details
    $servername = "localhost";
    $username = "root";
    $password = "PlariDeals2k24";
    $dbname = "plarideals";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>