<?php
include 'db.php';

// Check if aID is set in the URL
if (isset($_GET['aID'])) {
    // Get the announcement ID from the URL
    $aID = $_GET['aID'];

    // Create connection
    $conn = connect_to_database();

    // Prepare and execute SQL query to fetch the announcement
    $sql = "SELECT * FROM announcement WHERE aID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $aID);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the announcement exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Announcement not found.";
        exit;
    }

    // Close the connection
    $stmt->close();
    $conn->close();
} else {
    echo "No announcement selected.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Announcement</title>
</head>
<body>

<h1><?php echo htmlspecialchars($row['title']); ?></h1>
<p><strong>Date:</strong> <?php echo htmlspecialchars($row['date']); ?></p>
<p><strong>Posted By:</strong> <?php echo htmlspecialchars($row['posted_by']); ?></p>
<p><strong>Message:</strong> <?php echo nl2br(htmlspecialchars($row['message'])); ?></p>

<a href="../admin/see_announcements.php">Back</a>

</body>
</html>
