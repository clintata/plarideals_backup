﻿<?php
include "../template/templateCashier.php";
include "../Modal/BillingPaidmodal.php";
include "../Modal/viewBillModal.php";
?>
<!DOCTYPE html>
<html lang="en">

<body>

	<div class="container mt-5">
		<h2>Billing List Report</h2>
		<table id="example" class="table table-striped table-bordered" style="width:100%">
			<thead>
				<tr>
					<th>CID</th>
					<th>Full Name</th>
					<th>Amount</th>
					<th>Bill Date</th>
					<th>Cutting Date</th>
					<th>Barangay</th>
					<th>Purok</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

	<script>
		const API_URL = 'https://plarideals.mooo.com/app/view'; // Replace with actual URL

		$(document).ready(function () {
			$('#example').DataTable({
				dom: 'Bfrtip',
				buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
				ajax: {
					url: `${API_URL}/billingAPI.php/billing`,
					dataSrc: ''
				},
				columns: [
					{ data: 'cID' },
					{ data: 'consumer_name' },
					{ data: 'amount' },
					{ data: 'bill_date' },
					{ data: 'cutting_date' },
					{ data: 'barangay' },
					{ data: 'purok' },
					{ data: 'purok' },
				],
				responsive: true,
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});
		});
	</script>
</body>

</html>