<?php
require_once '../processes/db.php'; // Include database connection
require_once '../processes/senderRemenders.php'; // Include SMS sender function

$conn = connect_to_database();

// Function to validate and format phone numbers in E.164 format
function format_phone_number($phone)
{
    $phone = preg_replace('/\D/', '', $phone); // Remove all non-numeric characters

    if (preg_match('/^0\d{10}$/', $phone)) {
        $phone = '+63' . substr($phone, 1); // Convert local Philippine format to E.164
    } elseif (preg_match('/^63\d{10}$/', $phone)) {
        $phone = '+' . $phone; // Add "+" if it starts with "63" but no "+" sign
    }

    if (preg_match('/^\+\d{10,15}$/', $phone)) {
        return $phone; // Valid E.164 format
    }
    return false; // Invalid format
}

// SQL query to get the latest unpaid bills with consumer details
$sql = "
SELECT 
    a.amount, 
    a.bill_date, 
    b.consumer_name, 
    b.phone, 
    b.consumer_id, 
    a.cutting_date
FROM 
    bill a
INNER JOIN 
    consumer b ON a.cID = b.consumer_id
INNER JOIN (
    SELECT cID, MAX(bNo) AS max_bNo
    FROM bill
    GROUP BY cID
) AS max_bill ON a.cID = max_bill.cID AND a.bNo = max_bill.max_bNo
WHERE 
    a.status <> 'PAID'
    AND EXTRACT(YEAR FROM a.cutting_date) = EXTRACT(YEAR FROM CURRENT_DATE)
    AND EXTRACT(MONTH FROM a.cutting_date) = EXTRACT(MONTH FROM CURRENT_DATE)
ORDER BY 
    a.bill_date DESC;
";

$result = $conn->query($sql);
if (!$result) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Database Error',
            text: 'Unable to retrieve data from the database.',
        });
    </script>";
    exit();
}

$allSentSuccessfully = true;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Send Reminders</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $phone = $row['phone'];
            $amount = $row['amount'];
            $bill_date = $row['bill_date'];
            $cutting_date = $row['cutting_date'];
            $consumer_name = $row['consumer_name'];
            $consumer_id = $row['consumer_id'];

            $formatted_phone = format_phone_number($phone);

            $message = "Hello $consumer_name, this is a reminder that your water service may be cut off on $cutting_date if your bill of $amount remains unpaid. Please pay promptly to avoid interruption. Thank you, PlariDeals.";

            $response = SendMessages($formatted_phone, $message);


            $query = "INSERT INTO notification (consumer_id, Title, Message, date_reference) VALUES (?, 'Reminder', ?, NOW());";

            try {
                // Prepare the statement with $query, not $sql
                $stmt = $conn->prepare($query);

                if ($stmt) {
                    // Bind the parameters (assuming $id is an integer, and $Message is a string)
                    $stmt->bind_param('ss', $consumer_id, $message);

                    if ($stmt->execute()) {
                        continue;
                    } else {
                    }
                } else {
                    echo 'Prepare Error: ' . $conn->error;
                }
            } catch (mysqli_sql_exception $e) {
                echo 'Create Error: ' . $e->getMessage();
            }

            if (isset($response['status']) && ($response['status'] === 'Pending' || $response['status'] === 'Sent')) {
                // Successfully sent or pending, no additional action needed
            } else {
                $allSentSuccessfully = true;
            }
        }
    } else {
        echo "<script>
        Swal.fire({
            icon: 'info',
            title: 'No Unpaid Bills Found',
            text: 'There are no unpaid bills to send reminders for.'
        }).then(() => {
            window.history.back(); // Redirect to the last page if no unpaid bills are found
        });
    </script>";
        $conn->close();
        exit();
    }

    $conn->close();
    ?>

    <script>
        // Display final success or error message without loading
        if (<?php echo json_encode($allSentSuccessfully); ?>) {
            Swal.fire({
                icon: 'success',
                title: 'Cutting Notice Sent Successfully',
                text: 'All unpaid bill reminders for cutting notices have been successfully sent!'
            }).then(() => {
                window.history.back(); // Redirect to the last page
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Partial Success',
                text: 'Some notice could not be sent. Please check the log for details.'
            }).then(() => {
                window.history.back(); // Redirect to the last page
            });
        }
    </script>

</body>

</html>