﻿<?php
include "../template/template.php"; // Keep the design template
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Billing List Report</title>
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
</head>

<body>
  <div class="content-body">
    <div class="container-fluid">
      <div class="row page-titles">
        <ol class="breadcrumb">
          <li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="javascript:void(0)">Complait List Report</a></li>
        </ol>
      </div>

      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <div class="row g-2 align-items-center">
                <div class="col-auto">
                  <label for="date_from" class="col-form-label">Date From:</label>
                </div>
                <div class="col-md-3">
                  <input type="date" class="form-control form-control-sm" id="date_from">
                </div>
                <div class="col-auto">
                  <label for="date_to" class="col-form-label">Date To:</label>
                </div>
                <div class="col-md-3">
                  <input type="date" class="form-control form-control-sm" id="date_to">
                </div>
                <div class="col-auto">
                  <button id="filter" class="btn btn-primary btn-sm">Filter</button>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                    <tr>
                      <th>Date Created</th>
                      <th>Consumer Name</th>
                      <th>Message</th>
                      <th>Note</th>
                      <th>Assigned To</th>
                      <th>Role</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

  <script>
    const API_URL = 'https://plarideals.mooo.com/app/view'; // Replace with actual API URL

    $(document).ready(function () {
      // Initialize DataTable with export buttons
      const table = $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        ajax: {
          url: `${API_URL}/ReportAPI.php/report?action=readComplaint`,
          data: function (d) {
            // Send date filters as parameters in AJAX request
            d.date_from = $('#date_from').val();
            d.date_to = $('#date_to').val();
          },
          dataSrc: function (json) {
            // Check if the data is empty
            if (json.length === 0) {
              alert('No data found for the selected date range.');
            }
            return json;
          }
        },
        columns: [
          { data: 'date_reference' },
					{ data: 'consumer_name' },
					{ data: 'message' },
					{ data: 'note' },
					{ data: 'fullName' },
					{ data: 'usertype' },
					{ data: 'status' },
        ],
        responsive: true,
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        pageLength: 10
      });

      // Reload DataTable with date filters on button click
      $('#filter').on('click', function () {
        table.ajax.reload();
      });
    });


  </script>
</body>

</html>