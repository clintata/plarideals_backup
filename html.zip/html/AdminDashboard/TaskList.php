﻿<?php
include "../template/templateBiller.php";
include "../Modal/Taskmodal.php";
?>
<!DOCTYPE html>
<html lang="en">

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">Tasks List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
				<div class="card-header">
					<button class="btn btn-primary float-end" id="basicModal" data-bs-toggle="modal"
						data-bs-target="#exampleModalCenter">Add Task</button>
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-2 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>Assign To</th>
											<th>Title</th>
											<th>Message</th>
											<th>Note</th>
											<th>Start Date</th>
											<th>Date Finished</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here -->
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</div>
	<!-- Datatable -->
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="url.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}

			// Initialize DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/TasksAPI.php/tasks',
					dataSrc: function (json) {
						// Process the data if needed
						return json;
					}
				},
				columns: [
					{ data: 'fullName', defaultContent: '' },
					{ data: 'title', defaultContent: '' },
					{ data: 'message', defaultContent: '' },
					{ data: 'note', defaultContent: '' },
					{ data: 'start_date', defaultContent: '' },
					{ data: 'date_finished', defaultContent: '' },
					{ data: 'status', defaultContent: '' },
					{
						data: null,
						render: function (data, type, row) {
							return `
						<a class="btn btn-primary btn-sm update-task-btn">Update</a>
						<a class="btn btn-danger btn-sm delete-task-btn" data-id="${row.tID}">Delete</a>
					`;
						}
					}
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});
			// Add a click event listener to the "Update" button
			$('#example3 tbody').on('click', '.update-task-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				console.log(data);
				var idNum = data.idNum;
				var title = data.title;
				var message = data.message;
				var note = data.note;
				var start_date = data.start_date;
				var tID = data.tID;

				$('#idTrackInput').val(tID);
				$('#titleInput').val(title);
				$('#MessageInput').val(message);
				$('#NoteInput').val(note);
				$('#birthDay').val(start_date);
				$('#personnelSelect').val(idNum).change;
				// Show the modal
				$('#exampleModalCenter').modal('show');
			});

			$('#example3 tbody').on('click', '.delete-task-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');
				var id = data.tID;
				Swal.fire({
					title: 'Are you sure?',
					text: "You won't be able to revert this!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					console.log(result); // Check the result object here
					if (result.value === true) { // Changed from result.isConfirmed
						$.ajax({
							url: API_URL + '/TasksAPI.php/tasks',
							method: 'DELETE',
							contentType: 'application/json', // Set the content type to JSON
							data: JSON.stringify({  // Convert data to JSON string
								id: id
							}),
							dataType: 'json',
							success: function (response) {
								console.log(response);
								if (response.success) {
									Swal.fire('Deleted!', response.message, 'success');
									setTimeout(function () {
										location.reload(); // Refresh the page after a short delay
									}, 10);
								} else {
									Swal.fire('Error', response.message, 'error');
								}
							},
							error: function (xhr, status, error) {
								console.log(xhr);
								console.error('Error deleting form of payment');
							}
						});
					} else {
						console.log('Deletion cancelled');
					}
				});
			});
		});


	</script>
</body>

</html>