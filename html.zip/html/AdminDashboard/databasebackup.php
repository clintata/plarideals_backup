<?php

// Database configuration
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'PlariDeals2k24';
$dbname = 'plarideals';
$tables = '*';

// Call the core function
backup_tables($dbhost, $dbuser, $dbpass, $dbname, $tables);

// Core function
function backup_tables($host, $user, $pass, $dbname, $tables = '*') {
    try {
        $link = new mysqli($host, $user, $pass, $dbname);

        // Check connection
        if ($link->connect_error) {
            throw new Exception("Connection failed: " . $link->connect_error);
        }

        mysqli_query($link, "SET NAMES 'utf8'");

        // Get all tables
        if ($tables == '*') {
            $tables = array();
            $result = mysqli_query($link, 'SHOW TABLES');
            while ($row = mysqli_fetch_row($result)) {
                $tables[] = $row[0];
            }
        } else {
            $tables = is_array($tables) ? $tables : explode(',', $tables);
        }

        $return = '';

        // Cycle through tables
        foreach ($tables as $table) {
            $result = mysqli_query($link, 'SELECT * FROM ' . $table);
            $num_fields = mysqli_num_fields($result);

            $return .= 'DROP TABLE IF EXISTS ' . $table . ';';
            $row2 = mysqli_fetch_row(mysqli_query($link, 'SHOW CREATE TABLE ' . $table));
            $return .= "\n\n" . $row2[1] . ";\n\n";
            $counter = 1;

            // Over tables
            for ($i = 0; $i < $num_fields; $i++) {
                // Over rows
                while ($row = mysqli_fetch_row($result)) {
                    if ($counter == 1) {
                        $return .= 'INSERT INTO ' . $table . ' VALUES(';
                    } else {
                        $return .= '(';
                    }

                    // Over fields
                    for ($j = 0; $j < $num_fields; $j++) {
                        $row[$j] = addslashes($row[$j]);
                        $row[$j] = str_replace("\n", "\\n", $row[$j]);
                        if (isset($row[$j])) {
                            $return .= '"' . $row[$j] . '"';
                        } else {
                            $return .= '""';
                        }
                        if ($j < ($num_fields - 1)) {
                            $return .= ',';
                        }
                    }

                    if ($num_fields == $counter) {
                        $return .= ");\n";
                    } else {
                        $return .= "),\n";
                    }
                    ++$counter;
                }
            }
            $return .= "\n\n\n";
        }

        // Ensure backup directory exists
        $downloadPath = 'backup/';
        if (!is_dir($downloadPath)) {
            mkdir($downloadPath, 0777, true); // Create directory with full permissions
        }

        $fileName = $downloadPath . 'db-backup-' . time() . '-' . (md5(implode(',', $tables))) . '.sql';  
        $handle = fopen($fileName, 'w+');

        if ($handle === false) {
            throw new Exception("Failed to open file: " . $fileName);
        }

        fwrite($handle, $return);
        fclose($handle);

        // Start session if not already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['backup_success'] = true;

    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['backup_success']) && $_SESSION['backup_success']) {
            unset($_SESSION['backup_success']);
        ?>
            Swal.fire({
                icon: 'success',
                title: 'Backup Successful',
                text: 'The database backup has been created successfully.',
            }).then(() => {
                window.location.href = 'index.php';
            });
        <?php } ?>
    });
</script>
