﻿<?php
include "../template/template.php";
include "../Modal/usermodal.php";
// require_once('repository/UsersRepository.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>User List</title>
	<!-- Include your CSS files here -->
	<link rel="stylesheet" href="../vendor/datatables/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../vendor/jquery-nice-select/css/nice-select.css">
	<!-- Add any additional CSS files you need -->
</head>

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">User List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
				<div class="card-header">
					<button class="btn btn-primary float-end" id="basicModal" data-bs-toggle="modal"
						data-bs-target=".bd-example-modal-lg">Add User List</button>
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-4 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>User Code</th>
											<th>Name</th>
											<th>Email</th>
											<th>User Type</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here by DataTables -->
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Include your JavaScript files here -->
	<script src="../vendor/global/global.min.js"></script>
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script src="url.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}
			// Now initialize the DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/userAPI.php/users',
					dataSrc: ''
				},
				columns: [
					{ data: 'idNum' },
					{ data: 'fullName' },
					{ data: 'email' },
					{ data: 'usertype' },
					{
						data: null,
						render: function (data, type, row) {
							return `
						<a class="btn btn-primary btn-sm update-user-btn">Update</a>
						<a class="btn btn-danger btn-sm delete-user-btn" data-id="${row.idNum}">Delete</a>
					`;
						}
					}
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});

			// Event delegation for dynamically created elements
			$('#example3 tbody').on('click', '.update-user-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');
				var idNum = data.idNum;
				var fullName = data.fullName;
				var email = data.email;
				var password = data.password;
				var update = 'someValue';
				var usertype = data.usertype;
				// Populate the modal fields with the extracted data
				$('#UpdateInputs').val(update);
				$('#userInputs').val(idNum);
				$('#fullNameInput').val(fullName);
				$('#emailInput').val(email);
				$('#passwordInput').val(password);
				$('#usertypeSelect').val(usertype).change;
				// Show the modal
				$('#userModal').modal('show');
			});

			$('#example3 tbody').on('click', '.delete-user-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');
				var id = data.idNum;
				Swal.fire({
					title: 'Are you sure?',
					text: "You won't be able to revert this!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					console.log(result); // Check the result object here
					if (result.value === true) { // Changed from result.isConfirmed
						console.log('Confirmed, proceeding with deletion');
						$.ajax({
							url: API_URL + '/userAPI.php/users',
							method: 'DELETE',
							contentType: 'application/json', // Set the content type to JSON
							data: JSON.stringify({  // Convert data to JSON string
								id: id
							}),
							dataType: 'json',
							success: function (response) {
								console.log(response);
								if (response.success) {
									Swal.fire('Deleted!', response.message, 'success');
									setTimeout(function () {
										location.reload(); // Refresh the page after a short delay
									}, 10);
								} else {
									Swal.fire('Error', response.message, 'error');
								}
							},
							error: function (xhr, status, error) {
								console.log(xhr);
								console.error('Error deleting form of payment');
							}
						});
					} else {
						console.log('Deletion cancelled');
					}
				});
			});
		});
	</script>
</body>

</html>