﻿<?php
include "../template/template.php";
?>
<!DOCTYPE html>
<html lang="en">

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">Feedback List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
			<div class="card-header">
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-2 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>Date</th>
											<th>ID Number</th>
											<th>Message</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here -->
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</div>
	<!-- Datatable -->
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="url.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}

			// Initialize DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/FeedbackAPI.php/feedback',
					dataSrc: function (json) {
						// Process the data if needed
						return json;
					}
				},
				columns: [
					{ data: 'date', defaultContent: '' },
					{ data: 'idNum', defaultContent: '' },
					{ data: 'message', defaultContent: '' },
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});


			// Add a click event listener to the "Update" button
			$('#example3').on('click', '.update-concern-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');

				var keyctr = data.keyctr;
				var concern_lvl = data.concern_lvl;
				var expected_day = data.expected_day;
				console.log(keyctr);

				$('#idTrackInput').val(keyctr);
				$('#concernlevelInput').val(concern_lvl);
				$('#expectedInput').val(expected_day);
				// Show the modal
				$('#exampleModalCenter').modal('show');
			});
		});


	</script>
</body>

</html>