﻿<?php
include "../template/template.php";
include "../Modal/announcementmodal.php";
include "../Modal/viewannouncementmodal.php";
// require_once('repository/UsersRepository.php');
?>
<!DOCTYPE html>
<html lang="en">

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">Announcements List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
				<div class="card-header">
					<button class="btn btn-primary float-end" id="basicModal" data-bs-toggle="modal"
						data-bs-target="#exampleModalCenter">Add Announcements</button>
				</div>
				<div class="col-12">
					<div class="card">

						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-2 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>Title</th>
											<th>Date</th>
											<th>Message</th>
											<th>Posted By</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here -->
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</div>
	<!-- Datatable -->
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="url.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}

			// Initialize DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/announcementAPI.php/announcement',
					dataSrc: function (json) {
						// Process the data if needed
						return json;
					}
				},
				columns: [
					{ data: 'title', defaultContent: '' },
					{ data: 'date', defaultContent: '' },
					{ data: 'message', defaultContent: '' },
					{ data: 'posted_by', defaultContent: '' },
					{
						data: null,
						render: function (data, type, row) {
							return `
						<a class="btn btn-primary btn-sm update-company-btn">View</a>
						<a class="btn btn-danger btn-sm delete-company-btn" data-id="${row.aID}">Delete</a>
					`;
						}
					}
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});

			// Event delegation for dynamically created elements
			$('#example3 tbody').on('click', '.update-company-btn', function () {
				var data = table.row($(this).parents('tr')).data();
			});

			$('#example3 tbody').on('click', '.update-company-btn', function () {
				// Find the closest table row
				var data = table.row($(this).parents('tr')).data();
				var title = data.title;
				var date = data.date;
				var message = data.message;
				// Populate the modal fields with the extracted data
				$('#titleDisplays').text(title);
				$('#messageDisplays').text(message);
				$('#dateDisplays').text(date);
				// Show the modal
				$('#announceModalCenters').modal('show');
			});

			$('#example3').on('click', '.delete-company-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var id = data.aID;
				Swal.fire({
					title: 'Are you sure?',
					text: "You won't be able to revert this!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					if (result.value === true) { // Changed from result.isConfirmed
						$.ajax({
							url: API_URL + '/announcementAPI.php/announcement',
							method: 'DELETE',
							contentType: 'application/json', // Set the content type to JSON
							data: JSON.stringify({  // Convert data to JSON string
								id: id
							}),
							dataType: 'json',
							success: function (response) {
								console.log(response);
								if (response.success) {
									Swal.fire('Deleted!', response.message, 'success');
									setTimeout(function () {
										location.reload(); // Refresh the page after a short delay
									}, 10);
								} else {
									Swal.fire('Error', response.message, 'error');
								}
							},
							error: function (xhr, status, error) {
								console.log(xhr);
								console.error('Error deleting form of announcement');
							}
						});
					} else {
						console.log('Deletion cancelled');
					}
				});
			});
		});
	</script>
</body>

</html>