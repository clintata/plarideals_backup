﻿<?php

include "../template/template.php";
include "../Modal/Cubicmodal.php";
?>
<!DOCTYPE html>
<html lang="en">

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">Cubic List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
			<div class="card-header">
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-2 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>Cubic Defult</th>
											<th>Default Amount</th>
											<th>First Rate</th>
											<th>Second Rate</th>
											<th>Third Rate</th>
											<th>First Penalty</th>
											<th>Second Penalty</th>
											<th>Third Penalty</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here -->
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</div>
	<!-- Datatable -->
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="url.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}

			// Initialize DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/CubicAPI.php/cubic',
					dataSrc: function (json) {
						// Process the data if needed
						return json;
					}
				},
				columns: [
					{ data: 'cubic', defaultContent: '' },
					{ data: 'default_amount', defaultContent: '' },
					{ data: 'first_rate', defaultContent: '' },
					{ data: 'second_rate', defaultContent: '' },
					{ data: 'third_rate', defaultContent: '' },
					{ data: 'first_penalty', defaultContent: '' },
					{ data: 'second_penalty', defaultContent: '' },
					{ data: 'third_penalty', defaultContent: '' },
					{
						data: null,
						render: function (data, type, row) {
							return `<a class="btn btn-primary btn-sm update-cubic-btn">Update</a>`;
						}
					}
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});


			// Add a click event listener to the "Update" button
			$('#example3').on('click', '.update-cubic-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');

				var keyctr = data.keyctr;
				var cubic = data.cubic;
				var default_amount = data.default_amount;
				var first_rate = data.first_rate;
				var second_rate = data.second_rate;
				var third_rate = data.third_rate;
				var first_penalty = data.first_penalty;
				var second_penalty = data.second_penalty;
				var third_penalty = data.third_penalty;

				$('#idTrackInput').val(keyctr);
				$('#cubicInput').val(cubic);
				$('#defaultInput').val(default_amount);	
				$('#firstrate').val(first_rate);
				$('#secondrate').val(second_rate);
				$('#thirdrate').val(third_rate);		
				$('#firstpenalty').val(first_penalty);
				$('#secondpenalty').val(second_penalty);
				$('#thirdpenalty').val(third_penalty);
				// Show the modal
				$('#exampleModalCenter').modal('show');
			});
		});


	</script>
</body>

</html>