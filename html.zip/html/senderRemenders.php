<?php

// Function to send SMS
function SendMessage($number, $message)
{
    $ch = curl_init();
    $parameters = array(
        'apikey' => '66685d96a2d76d4414344a11f6b013f6', // Your API KEY
        'number' => $number,
        'message' => $message,
        'sendername' => 'PlariDeals'
    );

    curl_setopt($ch, CURLOPT_URL, 'https://semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $output = curl_exec($ch);

    if ($output === false) {
        echo 'cURL Error: ' . curl_error($ch);
        curl_close($ch);
        return;
    }

    curl_close($ch);

    echo "Response from Semaphore API: " . $output . "<br>";
}

$number = $_POST['number'] ?? 'recipient_number';
$message = $_POST['message'] ?? 'Your message content';

// Call the SendMessage function
SendMessage($number, $message);
?>
