-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2024 at 12:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plarideals`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `idNum` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expire` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`idNum`, `fullName`, `email`, `password`, `usertype`, `image_path`, `status`, `reset_token`, `reset_token_expire`) VALUES
('020302', 'Mary', 'mary@gmail.com', '123', 'cashier', NULL, NULL, NULL, NULL),
('1234', 'Darren Jay Anino', 'anino@gmail.com', 'Qwerty123#', 'personnel', 'uploads/FB_IMG_1730161048889.jpg', NULL, NULL, NULL),
('20190', 'Clintitus', 'clintcantilang@gmail.com', 'yes123', 'biller', NULL, NULL, '', ''),
('2022312722', 'James Akkjo', 'ja@gmail.com', '123', 'admin', NULL, NULL, NULL, NULL),
('2022312725', 'John Smith', 'js@yahoo.com', '123456', 'admin', NULL, NULL, NULL, NULL),
('20292', 'Tata', 'tata@gmail.com', '123', 'admin', NULL, NULL, NULL, NULL),
('223212', 'Jack Hanma', 'biller@gmail.com', '123', 'biller', NULL, NULL, NULL, NULL),
('39493', 'maria', 'maria@gmail.com', 'Yes123!', 'personnel', NULL, NULL, NULL, NULL),
('44666', 'Baki Hanma', 'cashier@yahoo.com', '1233', 'cashier', NULL, NULL, NULL, NULL),
('626598', 'Clintitus', 'clintituscantilang@gmail.com', 'Yes123!', 'personnel', NULL, NULL, NULL, NULL),
('6744', 'field Clint', 'clintcantilang@gmail.com', '123', 'personnel', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `aID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `atype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`aID`, `title`, `message`, `date`, `posted_by`, `atype`) VALUES
(10, 'Announcement', 'Hello PlariDeals, We have no Office this coming Monday . Thankyou', '2024-11-03', 'James Akkjo', ''),
(11, 'Announcement', 'Hello Everyone, We have free connection this coming tuesday. Thankyou', '2024-11-04', 'James Akkjo', ''),
(12, 'Announcement', 'Hello Everyone, We have the clearing operation this coming saturday , please be on time thankyou', '2024-11-03', 'James Akkjo', ''),
(13, 'Announcement', 'Goodmorning Everyone , we have chrismast party this coming Dec. 22, 2024', '2024-11-03', 'James Akkjo', ''),
(14, 'Announcement', 'Hello, Everyone  we have meeting this coming monday', '2024-11-04', 'James Akkjo', '');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bNo` int(11) NOT NULL,
  `cID` varchar(255) NOT NULL,
  `amount` double(11,2) NOT NULL,
  `bill_date` date NOT NULL,
  `cutting_date` date NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `purok` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `paid_amount` double(11,2) DEFAULT NULL,
  `previous_balance` double(11,2) NOT NULL,
  `previous_meter` int(11) NOT NULL,
  `current_meter` int(11) NOT NULL,
  `consumption` int(11) NOT NULL,
  `penalty` double(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bNo`, `cID`, `amount`, `bill_date`, `cutting_date`, `barangay`, `purok`, `street`, `status`, `paid_amount`, `previous_balance`, `previous_meter`, `current_meter`, `consumption`, `penalty`) VALUES
(6, 'CO2024102400003', 1000.00, '2024-10-25', '2024-10-31', 'unidos\r\n', '', '5', 'active', NULL, 10.00, 8, 8, 0, NULL),
(17, 'CO2024102400003', 176.40, '2024-10-28', '2024-11-09', 'khfshjefsejfhsekjfh', '', '5', 'active', NULL, 186.40, 8, 20, 12, 8.00),
(23, 'CO2024102400003', 140.70, '2024-10-28', '2024-11-09', 'khfshjefsejfhsekjfh', '', '5', 'active', NULL, 327.10, 20, 30, 10, 6.00),
(24, 'CO-110307', 122.85, '2024-10-28', '2024-11-09', '', '', '', 'active', NULL, 122.85, 0, 9, 9, 5.00),
(25, 'CO-110508', 140.70, '2024-10-28', '2024-11-09', '', '', '', 'active', NULL, 140.70, 0, 10, 10, 6.00),
(26, 'CO-110307', 105.00, '2024-10-28', '2024-11-09', '', '', '', 'active', NULL, 227.85, 9, 12, 3, 5.00);

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `chat_id` int(11) NOT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `receiver_id` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chat_id`, `sender_id`, `receiver_id`, `message`, `timestamp`) VALUES
(1, '1234', '4321', 'sdsd', '2024-09-29 13:11:34'),
(2, '4321', '1234', 'No way', '2024-09-29 13:21:15'),
(3, '4321', '1234', 'hahahaha', '2024-09-29 13:21:20'),
(4, '123', '1234', 'sgsbd', '2024-09-30 10:35:51'),
(5, '123', '1234', 'dfgdfgfdgtdfgrt', '2024-09-30 10:36:11'),
(6, '1234', '123', 'dljhwejkfhsg', '2024-09-30 10:37:31'),
(7, '1234', '4321', 'salkhclksac\\', '2024-09-30 10:38:36'),
(8, '11', '4321', 'sjhkdckjsdcs', '2024-09-30 13:19:07'),
(9, '11', '123', 'scacasdv', '2024-09-30 13:27:04'),
(10, '11', '1234', 'scdvwegwr', '2024-09-30 13:32:35'),
(11, '11', '11', 'ascsdvsfs', '2024-09-30 13:44:42'),
(12, '11', '123', 'felletmbl;fmb', '2024-09-30 13:48:51'),
(13, '123', '11', 'sdf,v\';sd,v\'e,\'gdb', '2024-09-30 13:49:40'),
(14, '123', '11', 'de,fsfldl;d,g', '2024-09-30 13:49:44'),
(17, '766', '123', 'ascac', '2024-09-30 22:13:23'),
(18, '111', '4356', 'hiiiii', '2024-10-01 09:05:35'),
(19, '321', '4321', 'hvghjvgfhjbkj', '2024-10-01 09:10:29'),
(20, '766', '766', 'fsvbdfbdfb', '2024-10-01 11:19:00'),
(21, '1233', '1233', 'csacascav', '2024-10-01 11:54:13'),
(22, '1233', '0', 'svasvddsbdbsfb', '2024-10-01 11:54:25'),
(23, '0', '1233', 'fdvgdfkjbhsjkvgkljbksv', '2024-10-01 11:55:03'),
(24, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:36'),
(25, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:39'),
(26, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:39'),
(27, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:40'),
(28, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:40'),
(29, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:40'),
(30, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:40'),
(31, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:41'),
(32, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:41'),
(33, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:59'),
(34, '123', '1233', 'heyyyyyy', '2024-10-01 13:54:59'),
(35, '123', '1233', 'heyyyyyy', '2024-10-01 13:55:00'),
(36, '123', '1233', 'heyyyyyy', '2024-10-01 13:55:00'),
(37, '123', '1233', 'heyyyyyy', '2024-10-01 13:55:00'),
(38, '123', '1233', 'wassssaapp', '2024-10-01 13:57:06'),
(39, '123', '1233', 'wassssaapp', '2024-10-01 13:57:13'),
(40, '123', '1233', 'wassssaapp', '2024-10-01 13:57:13'),
(41, '123', '1233', 'wassssaapp', '2024-10-01 13:57:14'),
(42, '123', '1233', 'wassssaapp', '2024-10-01 13:57:14'),
(43, '123', '0', 'casvsbsf', '2024-10-01 13:57:54'),
(44, '123', '0', 'casvsbsf', '2024-10-01 13:57:55'),
(45, '123', '0', 'casvsbsf', '2024-10-01 13:57:57'),
(46, '123', '0', 'casvsbsf', '2024-10-01 13:57:58'),
(47, '123', '0', 'casvsbsf', '2024-10-01 13:57:59'),
(48, '123', '11', 'dvdvsvs', '2024-10-01 13:58:28'),
(49, '123', '11', 'dvdvsvs', '2024-10-01 13:58:29'),
(50, '123', '11', 'dvdvsvs', '2024-10-01 13:58:31'),
(51, '123', '11', 'dvdvsvs', '2024-10-01 13:58:32'),
(52, '123', '0', 'fdbdbvnd', '2024-10-01 13:58:57'),
(53, '123', '0', 'vsdvsvf', '2024-10-01 14:31:31'),
(54, '123', '78', 'adasbdkjafkjdhga', '2024-10-01 14:32:11'),
(55, '123', '78', 'dasffbsfbadfa', '2024-10-01 14:32:17'),
(56, '766', '11', 'sdsdgeafaf', '2024-10-01 21:01:28'),
(57, '232', '121', 'sdasfqwv', '2024-10-03 10:10:06'),
(58, '212', '11', 'dgdfhher', '2024-10-04 11:42:47'),
(59, '2221', '0976', 'cascsavava', '2024-10-04 15:49:28'),
(60, '2221', '11', 'svvdvsvav', '2024-10-04 15:50:48'),
(61, '2024', '2221', 'hahahhahhaa\'', '2024-10-07 08:31:45'),
(69, '123121', '111', 'jdvdjsbsbx', '2024-10-09 23:52:35'),
(70, '123121', '2221', 'ksvdbrksbxbbfbrd', '2024-10-12 10:45:32'),
(71, '123121', '111', 'wgvsec', '2024-10-13 14:59:18'),
(72, '65656', '98895', 'hdbxbsjjs', '2024-10-14 10:25:33'),
(73, '65656', '98895', 'hzhdbdbzjx', '2024-10-14 10:34:48'),
(74, '98895', '65656', 'jsbdhxjsbzbzhzms', '2024-10-14 10:35:33'),
(75, '98895', '659598', 'jfndbsnxbfbsnsz', '2024-10-14 10:52:29'),
(76, '98895', '659598', 'hdhdbjsbxbfs', '2024-10-14 10:52:31'),
(77, '65656', '98895', 'hxdbdndnxbdbsjdhx', '2024-10-14 11:01:33'),
(78, '65656', '98895', 'ksnxbdhejsbxbd', '2024-10-14 11:01:36'),
(79, '65656', '98895', 'hshdbdbsbxhd', '2024-10-14 11:02:05'),
(80, '58858', '956956', 'js sjsbxbdhsbsnss', '2024-10-14 11:29:08'),
(81, '65656', '98895', 'bxndnjsjzx', '2024-10-14 11:36:20'),
(82, '65656', '2024', 'tatatatata', '2024-10-14 11:36:41'),
(83, '65656', '98895', 'hxbejsbx d', '2024-10-14 11:42:34'),
(84, '65656', '98895', 'hdbejshsbsa', '2024-10-14 12:01:38'),
(85, '65656', '98895', 'yebanna x dnansbzbz', '2024-10-14 12:01:43'),
(86, '65656', '98895', 'nsnslx sks', '2024-10-14 13:33:56'),
(87, '65656', '98895', 'jxbejsjxns', '2024-10-14 13:38:14'),
(88, '65656', '98895', 'hsjwjsnsbshsjs', '2024-10-14 13:38:28'),
(89, '65656', '98895', 'wassssuoop man', '2024-10-14 13:38:35'),
(90, '65656', '2024', 'kkdnskskzks', '2024-10-14 13:56:27'),
(91, '98895', '65656', 'heyyyyyy', '2024-10-14 14:24:22'),
(92, '98895', '65656', 'wasssaaaaoopp', '2024-10-14 14:24:25'),
(93, '98895', '659598', 'jsjsbejsjsnhsshshshs', '2024-10-14 14:24:42'),
(94, '98895', '956956', 'hshshsbsbshshsjhss', '2024-10-14 14:24:51'),
(95, '98895', '956956', 'jshehsjdjdjdjd', '2024-10-14 14:24:55'),
(96, '65656', '98895', 'jjsjdndnskskskskkws', '2024-10-14 14:33:12'),
(97, '65656', '98895', 'gsbwbsnmskzmzmdnd', '2024-10-14 14:33:15'),
(98, '65656', '98895', 'hdjdjskkskdkdnfbfhejkskdd', '2024-10-14 14:33:18'),
(99, '65656', '98895', 'ukwwkkskdkdkdjsjsjsjdjxbd', '2024-10-14 14:34:21'),
(100, '98895', '123456', 'kdndnsks', '2024-10-14 14:35:23'),
(101, '98895', '123456', 'xkdkkjsd', '2024-10-14 14:35:25'),
(102, '98895', '65656', 'jzjxbdjskskxndnsksksksks', '2024-10-14 14:35:36'),
(103, '98895', '65656', 'sumooooo', '2024-10-14 14:35:39'),
(104, '98895', '65656', 'najajajjsjsjsa', '2024-10-14 14:36:01'),
(105, '98895', '65656', 'hsjsjsjsjaja', '2024-10-14 14:36:08'),
(106, '98895', '5986898', 'bbshshshsjsjajababababs nganoooo', '2024-10-14 14:36:58'),
(107, '98895', '2024', 'kdkkdjdjsd', '2024-10-14 14:42:05'),
(108, '98895', '2024', 'bzbsbsbababa', '2024-10-14 14:42:14'),
(109, '98895', '58858', 'effbccngfvbf', '2024-10-14 14:42:44'),
(110, '65656', '555', 'jsjsjsjs', '2024-10-14 14:47:34'),
(111, '65656', '555', 'jjasbdbwjajcnfbskaozhcbfowa', '2024-10-14 14:47:47'),
(112, '65656', '555', 'ishfbejkskdndjd', '2024-10-14 14:47:50'),
(113, '65656', '555', 'ifjensbbdhdndhss', '2024-10-14 14:47:52'),
(114, '65656', '555', 'kdjbdnsnsjdbcbsjss', '2024-10-14 14:47:54'),
(115, '65656', '555', 'nsjejs', '2024-10-14 14:48:43'),
(116, '65656', '212', 'huhuhu pleaseee', '2024-10-14 14:49:41'),
(117, '65656', '555', 'yuaaaaa', '2024-10-14 14:49:49'),
(118, '65656', '555', 'jsjsjsjsjd', '2024-10-14 14:52:52'),
(119, '65656', '555', 'jsjsjejsjsjdjd', '2024-10-14 14:52:54'),
(120, '65656', '555', 'jsjsjdjshdjdjd', '2024-10-14 14:52:56'),
(121, '65656', '555', 'hzjsjsjsjs', '2024-10-14 14:53:04'),
(122, '65656', '555', 'jsbbzbdbsnsjxbdbsjs', '2024-10-14 14:53:06'),
(123, '65656', '555', 'bdbdbdbd', '2024-10-14 14:53:07'),
(124, '65656', '212', 'bsnsnsjsjs', '2024-10-14 14:56:37'),
(125, '65656', '212', 'pleaseeee', '2024-10-14 14:56:39'),
(126, '65656', '58858', 'haahhahahahahahahaha', '2024-10-14 14:56:49'),
(127, '65656', '58858', 'yagaaaaaa', '2024-10-14 14:56:50'),
(128, '65656', '58858', 'yagabdbnekaka', '2024-10-14 14:56:53'),
(129, '65656', '58858', 'kapoyaaaa', '2024-10-14 14:56:55'),
(130, '65656', '2024', 'jdjdjsjsjjsss', '2024-10-14 14:58:43'),
(131, '65656', '2024', 'hhhccghhhhjjbhh', '2024-10-14 14:59:00'),
(132, '65656', '1233', 'hdjsjsjsjajajajjsjsjss', '2024-10-14 14:59:08'),
(133, '65656', '1233', 'ywaaaa gagahahaha', '2024-10-14 14:59:42'),
(134, '65656', '98895', 'bshshshshshs', '2024-10-14 14:59:51'),
(135, '65656', '123456', 'nsjsjajsjsjsbwba', '2024-10-14 15:09:34'),
(136, '65656', '1233', 'jsjsjdjjdjsjsjsjs', '2024-10-14 15:09:41'),
(137, '65656', '1233', 'kdkdkdkdkdkdksksksksksk', '2024-10-14 15:09:44'),
(138, '65656', '1233', 'sa wakass bahahahaha', '2024-10-14 15:09:50'),
(139, '65656', '98895', 'jzhsbshshzhshxhs', '2024-10-14 15:25:54'),
(140, '65656', '98895', 'hzhdhshsjzjzbxbsbs', '2024-10-14 15:25:57'),
(141, '65656', '98895', 'jfjfjskkskzkzks', '2024-10-14 15:25:59'),
(142, '98895', '65656', 'testing testing testing', '2024-10-14 15:27:19'),
(143, '98895', '65656', 'testing', '2024-10-14 15:27:23'),
(144, '98895', '65656', 'testing', '2024-10-14 15:27:27'),
(145, '65656', '98895', 'jxhsnsnsjsjs', '2024-10-14 15:45:46'),
(146, '65656', '98895', 'jdjxnxndns', '2024-10-14 15:45:49'),
(147, '65656', '98895', 'mskxkdksmdmxmxmxn', '2024-10-14 15:45:56'),
(148, '65656', '98895', 'untaaaa mahumannn', '2024-10-14 15:46:13'),
(149, '65656', '98895', 'yagaaaa', '2024-10-14 15:56:31'),
(150, '65656', '98895', 'nananana uy ahak', '2024-10-14 16:36:27'),
(151, '65656', '98895', 'jahshdbsamkznxnxndnd', '2024-10-14 16:42:51'),
(152, '98895', '5986898', 'hdhdjjxjdjds', '2024-10-14 16:49:52'),
(153, '98895', '5986898', 'displayyy please', '2024-10-14 16:49:56'),
(154, '98895', '65656', 'hshshshshhhxd', '2024-10-14 16:50:22'),
(155, '98895', '65656', 'yagaaaaaaa', '2024-10-14 16:52:48'),
(156, '98895', '65656', 'untaaaa mahumaaan nataaaa ani hyhuhu', '2024-10-14 16:52:57'),
(157, '65656', '98895', 'hakdoggg', '2024-10-14 17:02:40'),
(158, '98895', '212', 'jdjdjdjsjs', '2024-10-14 17:10:20'),
(159, '98895', '212', 'jsjsjajajajajajaa', '2024-10-14 17:10:30'),
(160, '98895', '65656', 'jajajajajajjaa', '2024-10-14 17:12:41'),
(161, '98895', '659598', 'nxkskkakakakakakakalalalalallalalallalakalakakakakakakanfb dbsjsjsjdjdnsjsjsjsjsjsjs', '2024-10-14 17:14:23'),
(162, '65656', '98895', 'jsjsjsjsjsjjsjsjsa', '2024-10-14 17:41:57'),
(163, '65656', '98895', 'jajajajajajajanz', '2024-10-14 17:42:21'),
(164, '65656', '659598', 'bsjsjsjsnnfd', '2024-10-14 18:05:14'),
(165, '65656', '659598', 'jdjdnsnsnsnjsjss', '2024-10-14 18:05:17'),
(166, '98895', '65656', 'nnanananananajanana', '2024-10-14 20:54:15'),
(167, '98895', '65656', 'displayyy unaaaaa', '2024-10-14 20:54:21'),
(168, '65656', '98895', 'hsjdhehsjsnand', '2024-10-14 21:27:22'),
(169, '65656', '98895', 'latesssttt', '2024-10-14 21:27:25'),
(170, '65656', '98895', 'tesssstt', '2024-10-14 21:27:27'),
(171, '65656', '98895', 'testtt', '2024-10-14 21:27:29'),
(172, '65656', '659598', 'nsjjsjdjdjdjsjsksksjsjsnbdndbdhdjsjwjsjsjsjdjxjxbbdbsnsjx', '2024-10-14 21:41:10'),
(173, '65656', '58858', 'najsjajajajajaja', '2024-10-14 21:58:06'),
(174, '65656', '58858', 'yagaaaaaa', '2024-10-14 21:58:08'),
(175, '65656', '58858', 'kapoyaaaaa', '2024-10-14 21:58:10'),
(176, '65656', '5986898', 'yAbaba zbsnsnanananannananaa', '2024-10-14 21:58:48'),
(177, '65656', '5986898', 'nganoooo dykaaaa', '2024-10-14 21:58:57'),
(178, '98895', '58858', 'jsjdndnsnsnsnsns', '2024-10-14 22:29:53'),
(179, '98895', '555', 'clintituscantilang@gmail.com', '2024-10-14 22:30:08'),
(180, '98895', '659598', 'kaksjskskakakanzbdbebsbbzz', '2024-10-14 22:35:15'),
(181, '98895', '65656', 'njajsjsjsjsjsjajaja', '2024-10-15 08:46:42'),
(182, '98895', '65656', 'testing', '2024-10-15 08:46:45'),
(183, '98895', '65656', 'testingggg', '2024-10-15 08:46:48'),
(184, '98895', '65656', 'testingggg', '2024-10-15 08:46:50'),
(185, '65656', '98895', 'bahahahahahahhaa', '2024-10-15 08:52:11'),
(186, '98895', '659598', 'thankyouuuu huhuhuhu', '2024-10-15 08:55:44'),
(187, '65656', '98895', 'niceeeesssonessss', '2024-10-15 09:02:08'),
(188, '98895', '65656', 'yeyeyeyeyeyeye', '2024-10-15 09:02:48'),
(189, '65656', '659598', 'njdjsnsnsjsjajajajjaajajjajaaamamakkaakkakakalalalalalalalalalalalallalakakakasbbc dndjxbccbdjdjxjcbbdnsksoxhcb dnskxkcbfbdbsndncjjfjfjfjd', '2024-10-15 09:17:13'),
(190, '65656', '659598', 'yessssssss', '2024-10-15 10:27:31'),
(191, '65656', '123456', 'niceeee', '2024-10-15 10:27:52'),
(192, '65656', '212', 'ndjsjsjsjsjsjsjs', '2024-10-15 10:28:14'),
(193, '65656', '2024', 'nsjsjdhshsjsjjssjs', '2024-10-15 10:28:57'),
(194, '65656', '659598', 'hrhdhdhsjsjsjsjsjsjdjjdxjdbbsbsbs abakajsjdbdbdbenskkxbdbdjsjxbdbdjdkxndbdjsjxjd', '2024-10-15 10:29:25'),
(195, '65656', '1233', 'cllsbf eksksndbsbsbsb', '2024-10-15 10:29:54'),
(196, '125', '98895', 'heyyyyyy', '2024-10-15 10:57:14'),
(197, '125', '98895', 'im clinttt', '2024-10-15 10:57:17'),
(198, '125', '98895', 'how are you', '2024-10-15 10:57:22'),
(199, '98895', '125', 'goooood thankyouuu', '2024-10-15 10:58:34'),
(200, '127432', '125', 'tata', '2024-10-15 17:21:25'),
(201, '127432', '125', 'tala na kay hapon na kaayo', '2024-10-15 17:21:32'),
(202, '127432', '125', 'happy birthday tata', '2024-10-15 17:21:38'),
(203, '125', '98895', 'niceeeeeee', '2024-10-15 18:41:26'),
(204, '125', '127432', 'helllo maam I have done the task👍🏻', '2024-10-15 19:42:06'),
(205, '125', '98895', 'thankyouu', '2024-10-15 19:42:18'),
(206, '125', '46568', 'marycrisass', '2024-10-16 07:22:22'),
(207, '125', '46568', 'testingggg', '2024-10-16 07:22:31'),
(208, '125', '46568', 'testinggggh', '2024-10-16 07:22:35'),
(209, '46568', '125', 'hi hello how are u?', '2024-10-16 07:37:50'),
(210, '46568', '125', 'ha ha ha', '2024-10-16 07:39:14'),
(211, '46568', '125', 'jdnhs', '2024-10-16 07:39:50'),
(212, '125', '46568', 'hahahhw', '2024-10-16 07:40:26'),
(213, '46568', '125', 'fedg', '2024-10-16 07:40:55'),
(214, '125', '46568', 'khvkk', '2024-10-16 07:41:20'),
(215, '125', '46568', 'kajhsbd', '2024-10-16 07:41:45'),
(216, '46568', '125', 'dhdhdh', '2024-10-16 07:41:54'),
(217, '65656', '125', 'hellllo masterrrr clint', '2024-10-16 08:16:40'),
(218, '65656', '98895', 'hshahahhs', '2024-10-16 09:40:53'),
(219, '65656', '98895', 'hsbbwbsnzbd', '2024-10-16 09:40:57'),
(220, '65656', '98895', 'heyyyy', '2024-10-16 09:41:15'),
(221, '65656', '98895', 'im clint', '2024-10-16 09:41:21'),
(222, '65656', '98895', 'clint1', '2024-10-16 09:41:25'),
(223, '65656', '46568', 'crissssy', '2024-10-16 09:42:08'),
(224, '65656', '46568', 'crissssy', '2024-10-16 09:42:09'),
(225, '65656', '46568', 'cris', '2024-10-16 09:42:12'),
(226, '65656', '46568', 'ingna verana ba para mahuman ta', '2024-10-16 09:42:24'),
(227, '125', '2024', 'Hi', '2024-10-16 12:12:43'),
(228, '125', '46568', 'jsjsbsbskskjcbsbbsjaja', '2024-10-19 08:37:55'),
(229, '125', '46568', 'jsnxbsbsnxz', '2024-10-19 08:38:01'),
(230, '258680', '98988', 'jsnf rmaoksnzbx', '2024-10-19 12:11:27'),
(231, '598659', '46568', 'hellllooo', '2024-10-19 13:37:08'),
(232, '598659', '46568', 'wassssuppppp', '2024-10-19 13:37:12'),
(233, '202020', '125', 'abc', '2024-10-19 14:30:00'),
(234, '202020', '127432', 'def', '2024-10-19 14:30:14'),
(235, '202020', '258680', 'hig', '2024-10-19 14:30:23'),
(236, '202020', '46568', '123]', '2024-10-19 14:30:33'),
(237, '125', '598659', 'clintituscantilang@gmail.com', '2024-10-20 01:00:09');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `cpID` int(11) NOT NULL,
  `cID` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `assigned_to` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `date_reference` date DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`cpID`, `cID`, `message`, `status`, `assigned_to`, `role`, `date_reference`, `note`) VALUES
(2, 'CO-110307', 'broken meter', 'in-active', '', '', '2024-10-25', 'pending'),
(10, 'CO2024102400003', 'Broken Meter', 'pending', '', '', '2024-10-27', 'finished'),
(11, 'CO-110307', 'Leaking Hose', 'pending', '', '', '2024-11-01', 'pending'),
(12, 'CO2024102400003', 'fix the broken meter of this comsumer name cris, unidos', 'pending', '39493', '', '2024-11-03', 'pending'),
(13, 'CO2024102400003', 'fix the broken meter', 'pending', '', '', '2024-11-05', 'pending'),
(14, 'CO-110508', 'Leaking hose', 'pending', '', '', '2024-11-05', 'finished'),
(15, 'CO2024102400003', 'leaking water meter', 'pending', '', '', '2024-11-05', 'pending'),
(16, 'CO-102906', 'broken hose', 'pending', '', '', '2024-11-05', 'pending'),
(17, 'CO2024102400003', 'Broken meter ', 'pending', '', '', '2024-11-05', 'pending'),
(18, 'CO-102906', 'Changing new hose', 'pending', '', '', '2024-11-05', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `consumer`
--

CREATE TABLE `consumer` (
  `keyctr` int(11) NOT NULL,
  `consumer_id` varchar(255) DEFAULT NULL,
  `consumer_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_reference` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `barangay` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expire` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `consumer`
--

INSERT INTO `consumer` (`keyctr`, `consumer_id`, `consumer_name`, `email`, `phone`, `password`, `status`, `date_reference`, `address`, `street`, `barangay`, `reset_token`, `reset_token_expire`) VALUES
(3, 'CO2024102400003', 'Andres Bonifacio', 'andres@gmail.com', '09123779184', '123', 'ACTIVE', '2024-10-24', 'Plaridel', 'Purok 1', 'Panalsalan', NULL, NULL),
(6, 'CO-102906', 'Mary P. Rizal', 'mary@gmail.com', '09123779184', '123', 'active', '2024-10-29', 'Plaridel', 'Purok 2', 'Unidos', '58c811239b4efdd288ba7a726de6c681129d371b3d02b94331e3c7228bb7e3350f248a80afe7b781cc9f7048dc0d30cfa3aa', '2024-11-03 14:59:11'),
(7, 'CO-110307', 'Rodrigo R. Duterte', 'duterte@gmail.com', '09123779184', '123', 'active', '2024-11-03', 'Plaridel', 'Purok 1', 'Unidos', NULL, NULL),
(8, 'CO-110508', 'Juan Lune', 'juan@gmail.com', '09700827341', '123', 'active', '2024-11-05', 'Plaridel', 'Purok 3', 'Unidos', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `consumerfeedback`
--

CREATE TABLE `consumerfeedback` (
  `fID` int(11) NOT NULL,
  `idNum` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `consumerfeedback`
--

INSERT INTO `consumerfeedback` (`fID`, `idNum`, `message`, `date`) VALUES
(1, 'CO2024102400003', 'THANKYOUUU', '2024-10-30'),
(2, 'CO2024102400003', 'Thankyouu plarideals for the quick response', '2024-11-05');

-- --------------------------------------------------------

--
-- Table structure for table `cubic`
--

CREATE TABLE `cubic` (
  `keyctr` int(11) NOT NULL,
  `cubic` int(11) DEFAULT NULL,
  `default_amount` decimal(11,2) NOT NULL,
  `first_rate` decimal(10,2) NOT NULL,
  `second_rate` decimal(10,2) NOT NULL,
  `third_rate` decimal(10,2) NOT NULL,
  `first_penalty` decimal(10,2) NOT NULL,
  `second_penalty` decimal(10,2) NOT NULL,
  `third_penalty` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `cubic`
--

INSERT INTO `cubic` (`keyctr`, `cubic`, `default_amount`, `first_rate`, `second_rate`, `third_rate`, `first_penalty`, `second_penalty`, `third_penalty`) VALUES
(1, 8, 100.00, 17.00, 20.00, 30.00, 0.85, 1.00, 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fID` int(11) NOT NULL,
  `idNum` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fID`, `idNum`, `message`, `date`) VALUES
(1, '1234', 'niceee', '2024-09-28'),
(2, '1234', 'Good app', '2024-09-28'),
(3, '1234', 'very nice app', '2024-09-30'),
(5, '555', 'niceeeesyaa', '2024-10-13'),
(6, '555', 'super niceee', '2024-10-13'),
(7, '555', 'niceee application PlariDeals', '2024-10-13'),
(8, '555', 'very good app', '2024-10-13'),
(13, '555', 'niceoneeee', '2024-10-13');

-- --------------------------------------------------------

--
-- Stand-in structure for view `new_announcement`
-- (See below for the actual view)
--
CREATE TABLE `new_announcement` (
`aID` int(11)
,`title` varchar(255)
,`message` varchar(255)
,`date` date
,`posted_by` varchar(255)
,`atype` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `consumer_id` varchar(20) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL,
  `date_reference` date DEFAULT NULL,
  `keyctr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`consumer_id`, `Title`, `Message`, `date_reference`, `keyctr`) VALUES
('CO2024102400003', 'Billing', 'Your water bill for November is 140.70, due by 2024-10-28. Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS', '2024-11-03', 1),
('CO2024102400003', 'Reminder', 'Hello testtestdaw, your water bill of 140.70 is due on 2024-10-28. Please pay promptly to avoid late fees. Thank you, PlariDeals', '2024-11-03', 2),
('CO2024102400003', 'Reminder', 'Hello testtestdaw, your water bill of 140.70 is due on 2024-10-28. Please pay promptly to avoid late fees. Thank you, PlariDeals', '2024-11-05', 3),
('CO-110307', 'Billing', 'Your water bill for November is 122.85, due by 2024-10-28. Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS', '2024-11-05', 4),
('CO-110508', 'Billing', 'Your water bill for November is 140.70, due by 2024-10-28. Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS', '2024-11-05', 5),
('CO2024102400003', 'Reminder', 'Hello Andres Bonifacio, your water bill of 140.70 is due on 2024-10-28. Please pay promptly to avoid late fees. Thank you, PlariDeals', '2024-11-05', 6),
('CO-110307', 'Reminder', 'Hello Rodrigo R. Duterte, your water bill of 122.85 is due on 2024-10-28. Please pay promptly to avoid late fees. Thank you, PlariDeals', '2024-11-05', 7),
('CO-110508', 'Reminder', 'Hello Juan Lune, your water bill of 140.70 is due on 2024-10-28. Please pay promptly to avoid late fees. Thank you, PlariDeals', '2024-11-05', 8),
('CO-110307', 'Billing', 'Your water bill for November is 105.00, due by 2024-10-28. Please pay on time to avoid late fees.\n\nFor details, visit our website or call [09631234567].\n\nThank you,\nPLARIDEALS', '2024-11-05', 9);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `keyctr` int(11) NOT NULL,
  `reading_date` date NOT NULL,
  `due_date` date NOT NULL,
  `cutting_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`keyctr`, `reading_date`, `due_date`, `cutting_date`) VALUES
(1, '2024-10-01', '2024-10-28', '2024-11-09');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `tID` int(11) NOT NULL,
  `idNum` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `date_finished` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`tID`, `idNum`, `title`, `message`, `note`, `status`, `start_date`, `date_finished`) VALUES
(2, '6744', 'Broken Hose', 'please fix the broken hose', 'done', 'finished', '2024-10-21', '2024-11-04'),
(3, '1234', 'Broken meter', 'please fix the broken meter,unidos near in willows bakeshop', 'done', 'finished', '2024-10-25', '2024-11-04'),
(5, '1234', 'Broken Meter', 'please fix the broken meter', 'done', 'finished', '2024-11-04', '2024-11-04'),
(6, '626598', 'Broken hose and meter', 'Hello clint , please go to unidos look for name willow and fix their hose and meter ', 'donee na sir', 'finished', '2024-11-05', '2024-11-05'),
(7, '626598', 'leaking hose', 'please fix the leaking hose of Mr. Juan Lune', 'doneee sirrrr', 'finished', '2024-11-05', '2024-11-05');

-- --------------------------------------------------------

--
-- Table structure for table `user_deleted_announcements`
--

CREATE TABLE `user_deleted_announcements` (
  `id` int(11) NOT NULL,
  `idNum` int(11) NOT NULL,
  `announcement_id` int(11) NOT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_deleted_announcements`
--

INSERT INTO `user_deleted_announcements` (`id`, `idNum`, `announcement_id`, `deleted_at`) VALUES
(1, 223212, 11, '2024-11-03 14:01:56'),
(2, 44666, 13, '2024-11-03 14:04:29'),
(3, 44666, 12, '2024-11-03 14:06:11'),
(4, 44666, 11, '2024-11-03 14:06:18'),
(5, 44666, 13, '2024-11-03 14:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `user_deleted_complaint`
--

CREATE TABLE `user_deleted_complaint` (
  `id` int(11) NOT NULL,
  `idNum` int(11) DEFAULT NULL,
  `announcement_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `user_read_announcements`
--

CREATE TABLE `user_read_announcements` (
  `idNum` int(11) NOT NULL,
  `announcement_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_read_announcements`
--

INSERT INTO `user_read_announcements` (`idNum`, `announcement_id`) VALUES
(39493, 3),
(39493, 10),
(6744, 10),
(6744, 11),
(6744, 12),
(1234, 13),
(1234, 12),
(1234, 13),
(1234, 13),
(1234, 12),
(1234, 12),
(1234, 12),
(1234, 13),
(1234, 13),
(1234, 12),
(1234, 13),
(1234, 11),
(1234, 14);

-- --------------------------------------------------------

--
-- Structure for view `new_announcement`
--
DROP TABLE IF EXISTS `new_announcement`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `new_announcement`  AS SELECT `a`.`aID` AS `aID`, `a`.`title` AS `title`, `a`.`message` AS `message`, `a`.`date` AS `date`, `a`.`posted_by` AS `posted_by`, `a`.`atype` AS `atype` FROM `announcement` AS `a` WHERE exists(select 1 from `user_deleted_announcements` `b` where `a`.`aID` = `b`.`announcement_id` limit 1) is false ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`idNum`) USING BTREE,
  ADD KEY `idNum` (`idNum`) USING BTREE;

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`aID`) USING BTREE;

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bNo`) USING BTREE,
  ADD KEY `consumerfk` (`cID`) USING BTREE;

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`chat_id`) USING BTREE,
  ADD KEY `sender_id` (`sender_id`) USING BTREE,
  ADD KEY `receiver_id` (`receiver_id`) USING BTREE;

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`cpID`) USING BTREE,
  ADD KEY `cpcID_fk` (`cID`) USING BTREE,
  ADD KEY `assigned_to` (`assigned_to`) USING BTREE;

--
-- Indexes for table `consumer`
--
ALTER TABLE `consumer`
  ADD PRIMARY KEY (`keyctr`) USING BTREE,
  ADD KEY `consumer_id` (`consumer_id`) USING BTREE;

--
-- Indexes for table `consumerfeedback`
--
ALTER TABLE `consumerfeedback`
  ADD PRIMARY KEY (`fID`) USING BTREE,
  ADD KEY `idNum` (`idNum`) USING BTREE;

--
-- Indexes for table `cubic`
--
ALTER TABLE `cubic`
  ADD PRIMARY KEY (`keyctr`) USING BTREE;

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fID`) USING BTREE,
  ADD KEY `idNum` (`idNum`) USING BTREE;

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`keyctr`) USING BTREE;

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`keyctr`) USING BTREE;

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`tID`) USING BTREE,
  ADD KEY `idNum` (`idNum`) USING BTREE;

--
-- Indexes for table `user_deleted_announcements`
--
ALTER TABLE `user_deleted_announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_deleted_complaint`
--
ALTER TABLE `user_deleted_complaint`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `aID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `cpID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `consumer`
--
ALTER TABLE `consumer`
  MODIFY `keyctr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `consumerfeedback`
--
ALTER TABLE `consumerfeedback`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cubic`
--
ALTER TABLE `cubic`
  MODIFY `keyctr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `keyctr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `keyctr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `tID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_deleted_announcements`
--
ALTER TABLE `user_deleted_announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_deleted_complaint`
--
ALTER TABLE `user_deleted_complaint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`cID`) REFERENCES `consumer` (`consumer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `complaint`
--
ALTER TABLE `complaint`
  ADD CONSTRAINT `complaint_ibfk_1` FOREIGN KEY (`cID`) REFERENCES `consumer` (`consumer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `idNum_fk` FOREIGN KEY (`idNum`) REFERENCES `account` (`idNum`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
