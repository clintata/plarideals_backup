﻿<?php
include "../template/templateBiller.php";
include "../Modal/consumermodal.php";
// require_once('repository/UsersRepository.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>User List</title>
	<!-- Include your CSS files here -->
	<link rel="stylesheet" href="../vendor/datatables/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../vendor/jquery-nice-select/css/nice-select.css">
	<!-- Add any additional CSS files you need -->
</head>

<body>
	<div class="content-body">
		<div class="container-fluid">
			<div class="row page-titles">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="javascript:void(0)">Consumer List</a></li>
				</ol>
			</div>
			<!-- row -->
			<div class="row">
				<div class="card-header">
					<button class="btn btn-primary float-end" id="basicModal" data-bs-toggle="modal"
						data-bs-target=".bd-example-modal-lg">Add Consumer</button>
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table id="example3" class="table card-table display mb-4 dataTablesCard text-black"
									style="min-width: 845px">
									<thead>
										<tr>
											<th>Consumer ID</th>
											<th>Full Name</th>
											<th>Email</th>
											<th>Phone</th>
											<th>Address</th>
											<th>Barangay</th>
											<th>Purok</th>
											<th>Status</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<!-- User rows will be inserted here by DataTables -->
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Include your JavaScript files here -->
	<script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../js/plugins-init/datatables.init.js"></script>
	<script src="url.js"></script>
	<script src="../vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	<script>
		$(document).ready(function () {
			// Check if DataTable is already initialized
			if ($.fn.DataTable.isDataTable('#example3')) {
				// If it is, destroy the existing instance
				$('#example3').DataTable().destroy();
			}
			// Now initialize the DataTable
			var table = $('#example3').DataTable({
				ajax: {
					url: API_URL + '/consumerAPI.php/consumer',
					dataSrc: ''
				},
				columns: [
					{ data: 'consumer_id' },
					{ data: 'consumer_name' },
					{ data: 'email' },
					{ data: 'phone' },
					{ data: 'address' },
					{ data: 'barangay' },
					{ data: 'street' },
					{ data: 'status' },
					{
						data: null,
						render: function (data, type, row) {
							return `
						<a class="btn btn-primary btn-sm update-user-btn">Update</a>
						<a class="btn btn-danger btn-sm delete-user-btn" data-id="${row.idNum}">Delete</a>
					`;
						}
					}
				],
				responsive: true,
				dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip',
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				pageLength: 10
			});

			// Event delegation for dynamically created elements
			$('#example3 tbody').on('click', '.update-user-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var idNum = data.consumer_id; // Adjust according to your data source
				var fullName = data.consumer_name; // Adjust according to your data source
				var email = data.email;
				var phone = data.phone; // Assuming this field exists in your data
				var address = data.address; // Assuming this field exists in your data
				var barangay = data.barangay; // Assuming this field exists in your data
				var street = data.street; // Assuming this field exists in your data
				var password = data.password; // Adjust according to your data source
				console.log(idNum);
				// Populate the modal fields with the extracted data
				$('#UpdateInputs').val(idNum); // Use idNum to pass relevant ID
				$('#fullNameInput').val(fullName);
				$('#emailInput').val(email);
				$('#phoneInput').val(phone); // Added phone input field
				$('#addressInput').val(address); // Added municipality input field
				$('#barangayInput').val(barangay); // Added barangay input field
				$('#streetInput').val(street); // Added purok input field
				$('#passwordInput').val(password); // Added password field if necessary

				$('#userModal').modal('show');
			});

			$('#example3 tbody').on('click', '.delete-user-btn', function () {
				var data = table.row($(this).parents('tr')).data();
				var $row = $(this).closest('tr');
				var id = data.consumer_id;
				Swal.fire({
					title: 'Are you sure?',
					text: "You won't be able to revert this!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#3085d6',
					cancelButtonColor: '#d33',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					console.log(result); // Check the result object here
					if (result.value === true) { // Changed from result.isConfirmed
						console.log('Confirmed, proceeding with deletion');
						$.ajax({
							url: API_URL + '/consumerAPI.php/consumer',
							method: 'DELETE',
							contentType: 'application/json', // Set the content type to JSON
							data: JSON.stringify({  // Convert data to JSON string
								id: id
							}),
							dataType: 'json',
							success: function (response) {
								console.log(response);
								if (response.success) {
									Swal.fire('Deleted!', response.message, 'success');
									setTimeout(function () {
										location.reload(); // Refresh the page after a short delay
									}, 10);
								} else {
									Swal.fire('Error', response.message, 'error');
								}
							},
							error: function (xhr, status, error) {
								console.log(xhr);
								console.error('Error deleting form of payment');
							}
						});
					} else {
						console.log('Deletion cancelled');
					}
				});
			});
		});
	</script>
</body>

</html>