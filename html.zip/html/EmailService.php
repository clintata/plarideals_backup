<?php

class EmailService {
    private $serviceId;
    private $templateId;
    private $userId;
    private $accessToken;

    public function __construct() {
        $this->serviceId = getenv('EMAILJS_SERVICE_ID') ?: 'service_zdt0k31';
        $this->templateId = getenv('EMAILJS_TEMPLATE_ID') ?: 'template_npavh1z';
        $this->userId = getenv('EMAILJS_USER_ID') ?: 'WycPYf4bAMmFaMZLH';
        $this->accessToken = getenv('EMAILJS_ACCESS_TOKEN') ?: 'VNLbyUqR5fWgdYV98VEpj';
    }

    public function sendEmail($name, $email, $code) {
        $url = 'https://api.emailjs.com/api/v1.0/email/send';

        $data = [
            'service_id' => $this->serviceId,
            'template_id' => $this->templateId,
            'user_id' => $this->userId,
            'accessToken' => $this->accessToken,
            'template_params' => [
                'email' => $email,
                'from_name' => 'Plarideals',
                'name' => $name,
                'verification_code' => $code
            ]
        ];

        $options = [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json'
            ],
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_RETURNTRANSFER => true
        ];

        $curl = curl_init();
        curl_setopt_array($curl, $options);

        $response = curl_exec($curl);
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if ($response === false) {
            $error = curl_error($curl);
            curl_close($curl);
            return "Error sending email: $error";
        }

        curl_close($curl);

        if ($statusCode == 200) {
            return 'Password reset code sent!';
        } else {
            return "Failed to send password reset code. Status code: $statusCode. Response: $response";
        }
    }
}

?>
