﻿<?php
session_start(); // Start the session
if (isset($_SESSION['usertype']) || isset($_SESSION['fullname']) || isset($_SESSION['user_id'])) {
    if ($_SESSION['usertype'] == 'admin') {
        header("Location: ../AdminDashboard/index.php");
    } elseif ($_SESSION['usertype'] == 'biller') {
        header("Location: ../BillingDashboard/index.php");
    } elseif ($_SESSION['usertype'] == 'cashier') {
        header("Location: ../CashierDashboard/index.php");
    } else {
        echo "Invalid user type.";
    }
    exit();
}
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message after displaying it
}
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="admin, dashboard">
    <meta name="author" content="DexignZone">
    <meta name="robots" content="index, follow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>PlariDeals System</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="../images/logo1.png">
    <link href="css/style.css" rel="stylesheet">

    <!-- SweetAlert Library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>
<style>
    .logo-img {
        width: 100%;
        height: auto;
        max-width: 150px;
        display: block;
        margin: 0 auto;
    }

    .authincation {
        background-image: url('images/water.jpeg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
</style>

<body class="vh-100">
    <?php if (isset($error_message)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo $error_message; ?>',
                confirmButtonText: 'OK'
            });
        </script>
    <?php endif; ?>

    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-4">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <div class="text-center mb-2">
                                        <a href="index.php"><img src="images/logo1.png" alt="" class="logo-img"></a>
                                    </div>
                                    <form action="processes/check_login.php" method="POST">
                                        <input type="hidden" name="action" value="login">
                                        <div class="mb-2">
                                            <label class="mb-1"><strong>Email</strong></label>
                                            <input type="email" class="form-control" name="email" required autocomplete="username">
                                        </div>
                                        <div class="mb-2">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" class="form-control" name="password" required autocomplete="current-password">
                                        </div>
                                        <div class="row d-flex justify-content-between mt-3 mb-1">
                                            <div class="mb-2">
                                                <a href="forgot_password.php">Forgot Password</a>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Sign Me In</button>
                                        </div>
                                        <div class="row d-flex justify-content-between mt-3 mb-1">
                                            <div class="mb-2">
                                                <a href="./ConsumerDashboard/register.php">New Consumer?</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/dlabnav-init.js"></script>
</body>

</html>
