<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consumer Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-bootstrap-4@5/bootstrap-4.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <div class="card shadow-lg">
            <div class="card-header bg-primary text-white text-center">
                <h3>Consumer Registration</h3>
            </div>
            <form id="RegistrationForm" class="card-body">
                <input type="hidden" id="consumerId" value="">

                <!-- Full Name -->
                <div class="mb-3 row">
                    <label for="fullNameInput" class="col-sm-2 col-form-label">Full Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="fullNameInput" required>
                    </div>
                </div>

                <!-- Email -->
                <div class="mb-3 row">
                    <label for="emailInput" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" id="emailInput" placeholder="example@gmail.com" required>
                    </div>
                </div>

                <!-- Phone Number -->
                <div class="mb-3 row">
                    <label for="phoneInput" class="col-sm-2 col-form-label">Phone</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="phoneInput" required>
                    </div>
                </div>

                <!-- Municipality Fields -->
                <div class="mb-3 row">
                    <label for="addressInput" class="col-sm-2 col-form-label">Address</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="addressInput" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="barangayInput" class="col-sm-2 col-form-label">Barangay</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="barangayInput" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="purokInput" class="col-sm-2 col-form-label">Purok</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="purokInput" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="mb-3 row">
                    <label for="passwordInput" class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" id="passwordInput" placeholder="Password" required>
                    </div>
                </div>

                <!-- Buttons -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success" id="submitButton">Register</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
            </form>
        </div>
    </div>

    <!-- SweetAlert2 and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="url.js"></script>

    <script>
        $(document).ready(function () {
            // Update submit button based on the hidden input's value
            $('#consumerId').val() === "" ? $("#submitButton").text("Register") : $("#submitButton").text("Update");

            // Form submission handler
            $('#RegistrationForm').submit(function (e) {
                e.preventDefault();

                var consumerId = $('#consumerId').val();
                var fullName = $('#fullNameInput').val();
                var email = $('#emailInput').val();
                var password = $('#passwordInput').val();
                var municipality = $('#addressInput').val();
                var phone = $('#phoneInput').val();
                var barangay = $('#barangayInput').val();
                var purok = $('#purokInput').val();

                // Determine if creating or updating based on hidden consumerId field
                var action = consumerId === "" ? 'create' : 'update';
                var url = API_URL + '/consumerAPI.php/consumer';
                var method = action === 'create' ? 'POST' : 'PUT';
                var data = action === 'create'
                    ? { action: 'create', consumer_name: fullName, email, password, municipality, phone, barangay, purok }
                    : JSON.stringify({ consumer_id: consumerId, consumer_name: fullName, email, password, municipality, phone, barangay, purok });

                $.ajax({
                    url: url,
                    method: method,
                    contentType: action === 'update' ? 'application/json' : 'application/x-www-form-urlencoded',
                    data: data,
                    success: function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: action === 'create' ? 'Consumer registered successfully' : 'Consumer updated successfully',
                        }).then(() => {
                            $('#RegistrationForm')[0].reset(); // Clear form
                            window.location.href = 'index.php'; // Redirect to index page
                        });
                    },
                    error: function () {
                        Swal.fire('Error', 'There was an error processing your request.', 'error');
                    }
                });
            });
        });
    </script>
</body>
</html>
